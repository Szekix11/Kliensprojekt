const path = require('path');

module.exports = {
  entry: './src/index.js',
  devtool: 'inline-source-map',
  output: {
    filename: 'main.js',
    path: path.resolve(__dirname, 'dist'),
  },
  mode: 'development',
};

/*A kódban a következők találhatók:

    const path = require('path');: Ez a sor az npm csomagkezelővel elérhető path modult importálja, amely segít a fájl és mappa útvonalak kezelésében.

    module.exports = {...}: Ez az objektum exportálja a Webpack konfigurációt, amelynek a következő tulajdonságai vannak:

    entry: A forráskód belépési pontját határozza meg, azaz a fájlt, amelyből a Webpack indul és az összes modult elkezdi beolvasni. Ebben az esetben az index.js fájl az belépési pont.

    devtool: A forráskód hibakereséséhez szükséges eszköztár típusát határozza meg. Ebben az esetben az inline-source-map beállítás lett választva, ami forráskódban jeleníti meg a hibákat a böngésző fejlesztői eszközeiben.

    output: Az elkészült bundle fájl kimeneti beállításait tartalmazza. Meghatározza a kimeneti fájl nevét (main.js) és helyét (dist mappa a jelenlegi munkakönyvtáron belül).

    mode: A Webpack működési módját határozza meg. Az development mód beállítása esetén a generált kód lesz emberileg olvashatóbb és kevésbé lesz optimalizált, ami hasznos a fejlesztési folyamat során történő hibakereséshez és teszteléshez.*/