 (() => {
	"use strict"; 
 	var __webpack_modules__ = ({

 "./src/dragDropLogic.js":

((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__); /*Ez a kód az __webpack_exports__ 
objektumot inicializálja, amelyet a modul kifelé exportál. Az r (resolve) metódus 
a "module.exports" objektumra mutató referenciát adja vissza, így lehetővé teszi az 
exportálást. Ez az __webpack_require__ függvényben használatos. Az egész 
modulrendszer __webpack_require__-en alapul, amely függvényeket biztosít a 
modulok betöltéséhez és az exportált objektumok leké
rdezéséhez.*/
 __webpack_require__.d(__webpack_exports__, {
   "addDragDropFeature": () => ( addDragDropFeature)
 });
/*Ez a kód az __webpack_require__ objektum d metódusát használja, hogy definíciókat adjon 
hozzá a __webpack_exports__ objektumhoz, amelyek az exportált függvényeket tartalmazzák. 
Itt konkrétan az addDragDropFeature 
függvényt exportálja, amelyet az importáló fájlban elérhetővé tesz.*/
//
const addDragDropFeature=function (human) {
    const allDraggableDivs = document.querySelectorAll(".draggable");
    allDraggableDivs.forEach((div) => {
        for (let i = 0; i < div.children.length; i+=1) {
            div.children[i].addEventListener("mousedown", (e) => {
                
                div.dataset.index = e.target.dataset.index; 
            });
        }
    }); /*A addDragDropFeature függvény a játékos hajóinak húzás- és ejtési
     funkcióját adja hozzá a felülethez. Az összes húzható div-et kijelöli a draggable 
     osztály segítségével, majd minden gyermekére eseményfigyelőt helyez el a "mousedown" 
     eseményre. Az eseménykezelő megjegyzi a húzható div aktuális pozícióját, amelyre az egér mutat. 
     Ezt a pozíciót adja át a dataset objektumon keresztül a div-nek, amely az egérrel húzható. Ezzel a
     funkcióval a felhasználó az egérrel húzhatja a hajókat a megfelelő helyre a játéktáblán.*/

    const dragstart=function (e) {
        const shipBeingDragged = e.target;
        const positionOfMouseOnTheShip = shipBeingDragged.dataset.index;
        const lengthOfTheShip = shipBeingDragged.dataset.shiplength;
        const shipName = shipBeingDragged.id;
        const transferData = [positionOfMouseOnTheShip, lengthOfTheShip, shipName];
        e.dataTransfer.setData("ship-data", JSON.stringify(transferData));
    }; /*Ez a kód egy eseménykezelő függvényt definiál, amely a "dragstart" 
    eseményre van beállítva. Amikor a felhasználó elkezdi húzni egy hajót az egérrel, a 
    függvény lefut, és a hajó adatait a hajóra történő hivatkozással együtt átadja az e.dataTransfer 
    objektumon keresztül a JSON.stringify() segítségével. Az átviteli 
    adatok magukban foglalják a hajó helyzetét az egérmutatóval szemben, a hajó hosszát és nevét.*/

    const dragEnter=function (e) {
        e.preventDefault();
    };

    const dragOver=function (e) {
        e.preventDefault();
    };

    const isAShipAlreadyPlaced=function (
        cells_With_Same_Y_Axis_As_DropTarget,
        shipData,
        xAxisOfDroppedShipFirstPosition,
    ) {
        const cellsWithShipPlaced = cells_With_Same_Y_Axis_As_DropTarget.filter(
            (cell) => cell.classList.contains("dropped"),
        );
        // eslint-disable-next-line radix
        const shipsPositionsInXAxis = cellsWithShipPlaced.map((cell) => parseInt(cell.dataset.index.split(",")[0]));
        const potentialShipPositionsForCurrentShip = [];
        const shipLength = shipData[1];
        for (let i = 0; i < shipLength; i+=1) {
            let droppedShipPosition = xAxisOfDroppedShipFirstPosition;
            droppedShipPosition += i;
            potentialShipPositionsForCurrentShip.push(droppedShipPosition);
        }
        const totalOverlappedShipPositions =
      potentialShipPositionsForCurrentShip.some((potentialShipPosition) => shipsPositionsInXAxis.includes(potentialShipPosition));
        if (totalOverlappedShipPositions) {
            return true;
        }
        return false;

    };

    const isThereEnoughSpace=function (
        cells_With_Same_Y_Axis_As_DropTarget,
        shipData,
        xAxisOfDroppedShipFirstPosition,
    ) {
        const shiplength = Number(shipData[1]);
        const xAxisOfFirstCell =
      cells_With_Same_Y_Axis_As_DropTarget[0].dataset.index.split(",")[0];
        const xAxisOfLastCell =
      cells_With_Same_Y_Axis_As_DropTarget[
          cells_With_Same_Y_Axis_As_DropTarget.length - 1
      ].dataset.index.split(",")[0];
        if (
            xAxisOfFirstCell <= xAxisOfDroppedShipFirstPosition &&
      xAxisOfLastCell >= xAxisOfDroppedShipFirstPosition + (shiplength - 1)
        ) {
            // shilplength-1 because 95+5=100 but if you consider 95 and add 5 to it then it would be 99
            // you have to consider this nuance when working with gameboard cells
            return true; // means the ship can be placed
        }
        return false;

    };

    const checkIfDropValid=function (event, shipData) {
        const dropTargetCoordinates = event.target.dataset.index.split(",");
        const positionOfMouseOnTheShip = shipData[0];
        const xAxisOfDroppedShipFirstPosition =
      dropTargetCoordinates[0] - positionOfMouseOnTheShip;
        const humanGameboardCellsArray = [...humanGameboardCells];
        const cells_With_Same_Y_Axis_As_DropTarget = humanGameboardCellsArray.filter(
            (cell) => {
                const yAxisOfCell = cell.dataset.index.split(",")[1];
                const yAxisOfDropTarget = dropTargetCoordinates[1];
                return yAxisOfCell === yAxisOfDropTarget;
            },
        );

        if (
            isAShipAlreadyPlaced(
                cells_With_Same_Y_Axis_As_DropTarget,
                shipData,
                xAxisOfDroppedShipFirstPosition,
            )
        ) {
            return false; // means there is already a ship placed in the same axis
        } else if (
            isThereEnoughSpace(
                cells_With_Same_Y_Axis_As_DropTarget,
                shipData,
                xAxisOfDroppedShipFirstPosition,
            )
        ) {
            return true; // means the ship can be placed
        }
        return false;

    };

    const totalShips = 5;
    let dropCount = 0;

    const drop=function (e) {
        e.stopPropagation(); // stops the browser from redirecting.

        const xAxisOfDropTarget = Number(e.target.dataset.index.split(",")[0]);
        const shipDataJson = e.dataTransfer.getData("ship-data");
        const shipData = JSON.parse(shipDataJson);

        if (!checkIfDropValid(e, shipData)) {
            return false; // this will stop the function and thus the drop will not be handled
        }

        const shiplength = shipData[1];
        const positionOfMouseOnTheShip = shipData[0];
        const xAxisOfShipStartPosition = xAxisOfDropTarget - positionOfMouseOnTheShip;
        const shipName = shipData[2];
        human.gameboard.placeShip(`${ shipName }`, xAxisOfShipStartPosition);
        for (let i = 0; i < shiplength; i+=1) {
            humanGameboardCells[xAxisOfShipStartPosition + i].style.background =
        "#444444";
            humanGameboardCells[xAxisOfShipStartPosition + i].classList.add(
                "dropped",
            );
        }

        const draggable = document.querySelector(`#${ shipName }`);
        draggable.style.display = "none";
        dropCount += 1;
        if (dropCount === totalShips) {
            const startGameButton = document.querySelector("#start");
            startGameButton.style.display = "block";
        }
    };

    const humanGameboardCells = document.querySelectorAll(
        "#friendly-area-gameboard .square_div",
    );
    humanGameboardCells.forEach((cell) => {
        cell.addEventListener("dragenter", dragEnter);
        cell.addEventListener("dragover", dragOver);
        cell.addEventListener("drop", drop);
    });

    const draggableShips = document.querySelectorAll(".draggable");
    draggableShips.forEach((ship) => {
        ship.addEventListener("dragstart", dragstart);
    });
};




/***/ }),

/***/ "./src/gameLogic.js":



/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ai": () => (/* binding */ ai),
/* harmony export */   "computer": () => (/* binding */ computer),
/* harmony export */   "gameBoard": () => (/* binding */ gameBoard),
/* harmony export */   "getHitScoreOfBothPlayer": () => (/* binding */ getHitScoreOfBothPlayer),
/* harmony export */   "human": () => (/* binding */ human),
/* harmony export */   "humanPlayer": () => (/* binding */ humanPlayer),
/* harmony export */   "ship": () => (/* binding */ ship)
/* harmony export */ });
/*A fenti kódrészlet egy modul, amelynek exportált függvényei és objektumai a következők:

    ai: egy objektum, ami az AI játékost reprezentálja. A függvényei között szerepel a 
    calculateShotCoordinate, ami 
    meghatározza az AI lövési koordinátáját a stratégiája alapján, valamint a resetShotCoordinates, ami 
    nullára állítja az AI által már lőtt koordinátákat.
    computer: egy objektum, ami a számítógépes játékost reprezentálja. A függvényei között szerepel a 
    calculateShotCoordinate, ami meghatározza a számítógépes játékos lövési koordinátáját a véletlenszerű 
    stratégiája alapján.
    gameBoard: egy objektum, ami a játéktáblát reprezentálja. A függvényei között szerepel a placeShip, 
    ami elhelyezi a hajót a játéktáblán, a receiveAttack, ami fogadja a lövést és megállapítja, hogy 
    találat vagy nem, valamint az areAllShipSunk, ami ellenőrzi, hogy minden hajó elsüllyedt-e.
    getHitScoreOfBothPlayer: egy függvény, ami kiszámítja mindkét játékos találati arányát.
    human: egy objektum, ami az emberi játékost reprezentálja. A függvényei között szerepel a attack, 
    ami végrehajtja az emberi játékos támadását a megadott koordinátára.
    humanPlayer: egy függvény, ami létrehozza az emberi játékost.
    ship: egy függvény, ami létrehozza a hajót a megadott nevével és koordinátával, és nyilvántartja a 
    hajóra leadott találatokat. */

    //
const ship= function (shipname, coordinate) {
    let shipLength;
    switch (shipname) {
    case "carrier":
        shipLength = 5;
        break;
    case "battleship":
        shipLength = 4;
        break;
    case "destroyer":
        shipLength = 3;
        break;
    case "submarine":
        shipLength = 2;
        break;
        case "titanic":
            shipLength = 1;
            break;
    }
    const hitPositions = [];
    const hit=function (hitCoordinate) {
        hitPositions.push(hitCoordinate);
    };
    const isSunk=function () {
        if (hitPositions.length === shipLength) {
            return true;
        }
        return false;
    };
    return { coordinate, shipLength, hitPositions, hit, isSunk };
}; /*Ez a kód egy ship objektum konstruktort hoz létre, amely egy hajó tulajdonságait 
tárolja. Az objektum konstruktor paraméterei a shipname és a coordinate. A shipname segítségével
 a kód beállítja a hajó hosszát (shipLength) a megfelelő értékre a switch utasítás segítségével. 
 Az objektum konstruktorban definiálódnak a hajóhoz kapcsolódó metódusok, mint például a hitPositions, 
 amely egy tömb, amelyben tároljuk az összes találat pozícióját, a hit metódus, amely egy találatot hajt
 végre, és a isSunk metódus, 
amely igazzal tér vissza, ha a hajó minden része találatot kapott, és így elsüllyedt.*/

const gameBoard=function () {
    const shipList = [];
    const placeShip=function (shipname, coordinate) {
        shipList.push(ship(shipname, coordinate));
    };
    const missedHits = [];
    const receiveAttack=function (hitCoordinate) {
        for (let i = 0; i < shipList.length; i+=1) {
            if (
                hitCoordinate >= shipList[i].coordinate &&
        hitCoordinate < shipList[i].coordinate + shipList[i].shipLength
            ) {
                shipList[i].hit(hitCoordinate);
                break;
            } else if (i === shipList.length - 1) {
                // means,we are at the end of the loop but we did not find a hit
                missedHits.push(hitCoordinate);
            }
        }
    };
    const areAllShipSunk=function () {
        return shipList.every((ship) => ship.isSunk());
    };
    return { shipList, placeShip, receiveAttack, missedHits, areAllShipSunk };
};
/*A fenti kód egy gameBoard objektum generátor függvényt definiál. Ez az objektum reprezentálja a 
játéktáblát, amelyen a hajók vannak elhelyezve és amelyen az ellenséges játékosok támadásai fogadják.

Az obj.placeShip(shipname, coordinate) metódus hozzáad egy új hajót a shipList tömbhöz a megadott 
coordinate koordinátával és shipname nevével.

Az obj.receiveAttack(hitCoordinate) metódus kezeli az ellenséges támadást. Ha a koordináta egy hajóra 
mutat, akkor az adott hajó hit metódusa hívódik meg, és elvégzi a szükséges műveleteket (például beállítja a 
    találat jelzőt). Ha a koordináta nem talál hajót, akkor a koordináta az missedHits tömbhöz adódik hozzá, 
    hogy későbbi felhasználásra tárolódjon.

Az obj.areAllShipSunk() metódus meghatározza, hogy az összes hajó elsüllyedt-e. Ehhez az every 
metódust használja a shipList tömbön, és minden hajóra meghívja az isSunk metódust.

Végül, az objektum visszatér az obj.shipList, obj.placeShip, obj.receiveAttack, obj.missedHits,
 és obj.areAllShipSunk metódusokkal, amelyek elérhetők lesznek a kódban létrehozott objektumon keresztül.*/

const humanPlayer=function () {
    const gameboard = gameBoard();
    const attack=function (enemyGameBoard, attackCoordinate) {
        enemyGameBoard.receiveAttack(attackCoordinate);
    };
    return { gameboard, attack };
}; /*Ez a kód egy humanPlayer objektumot hoz létre, amelynek van egy gameboard 
és egy attack metódusa. A gameboard az emberi játékos saját játéktábláját reprezentálja,
 amelyen a játékos elhelyezi a hajóit, és amelyen követi az ellenfél támadásait. Az attack 
 metódus a támadás megvalósítására szolgál, amelynek az ellenfél játéktábláján kell történnie,
  és amelyet az ellenfél koordinátájával határoznak meg. 
A metódus a gameboard receiveAttack metódusát hívja meg a megadott koordinátával*/

const returnLastSuccessfulHitPositionOfEnemyGameboard=function (
    previousEnemyGameBoardHitPositions,
    enemyGameBoard,
) {
    let updatedEnemyGameboardHitPositions = [];
    enemyGameBoard.shipList.forEach((ship) => {
        updatedEnemyGameboardHitPositions =
      updatedEnemyGameboardHitPositions.concat(ship.hitPositions);
    });
    const lastHitPositionStr = updatedEnemyGameboardHitPositions
        // eslint-disable-next-line max-len
        .filter((position) => !previousEnemyGameBoardHitPositions.includes(position))
        .toString();
    if (
        updatedEnemyGameboardHitPositions.length >
    previousEnemyGameBoardHitPositions.length
    ) {
    // means last attack was successful
        // eslint-disable-next-line radix
        const lastHitPosition = parseInt(lastHitPositionStr);
        previousEnemyGameBoardHitPositions.push(lastHitPosition);
        return lastHitPosition;
    }
    return false; // means last attack was not successful

}; /*Ez a kód egy függvényt definiál, amely visszaadja az utolsó sikeres találat 
pozícióját az ellenséges játéktáblán. A függvény paraméterként kapja a korábbi ellenséges 
találatokat és az ellenséges játéktáblát. Először összegyűjti az összes aktualizált ellenséges 
találat pozícióját, majd eltávolítja belőle a korábbi találatokat. Ha az aktuális találatok száma 
nagyobb, mint a korábbi találatok száma, akkor az utolsó találat pozícióját adja vissza és hozzáadja
 azt a korábbi találatokhoz. Ha az aktuális találatok száma
 nem változott, akkor false értéket ad vissza, ami jelzi, hogy az utolsó támadás sikertelen volt.*/

const calculateShotCoordinate=function (
    previousEnemyGameBoardHitPositions,
    enemyGameBoard,
    coordinatesForAttack,
) {
    const lastHitPositionOfEnemyGameboard =
    returnLastSuccessfulHitPositionOfEnemyGameboard(
        previousEnemyGameBoardHitPositions,
        enemyGameBoard,
    );
    const coordinatesForAttackIncludeNextHit = coordinatesForAttack.includes(
        lastHitPositionOfEnemyGameboard + 1,
    );
    let shotCoordinate;

    if (lastHitPositionOfEnemyGameboard && coordinatesForAttackIncludeNextHit) {
    // means last attack was a hit
        shotCoordinate = lastHitPositionOfEnemyGameboard + 1;
        coordinatesForAttack.splice(
            coordinatesForAttack.indexOf(shotCoordinate),
            1,
        );
        return shotCoordinate;
    }
    shotCoordinate =
      coordinatesForAttack[
          Math.floor(Math.random() * coordinatesForAttack.length)
      ];
    coordinatesForAttack.splice(
        coordinatesForAttack.indexOf(shotCoordinate),
        1,
    );
    return shotCoordinate;

}; /*Ez a kód részlet egy függvényt definiál, amely kiszámolja, hogy
 az AI játékosnak hova kell támadnia a következő körben. Az előző támadások eredményét 
 figyelembe véve (sikeres vagy sikertelen találatok) és az ellenséges játéktábla állapotát 
 felhasználva a függvény véletlenszerűen választ egy koordinátát, amelyet a játékos támadni fog 
 a következő körben, és eltávolítja azt a koordináta listából, hogy ne támadja újra ugyanazt a 
 koordinátát. Ha az előző támadás egy sikeres találat volt, akkor a függvény a következő találat 
 koordinátáját adja vissza, amely az előző találat mellett vagy alatt van (vízszintesen vagy függőlegesen).
  Ha az előző támadás 
sikertelen volt, akkor a függvény véletlenszerűen választ egy koordinátát a támadáshoz.*/

const ai=function () {
    const gameboard = gameBoard();
    const gameBoardSize = 100;
    const coordinatesForAttack = [];
    for (let i = 0; i < gameBoardSize; i+=1) {
        coordinatesForAttack.push(i);
    }
    const previousEnemyGameBoardHitPositions = [];

    const attack=function (enemyGameBoard) {
        const shotCoordinate = calculateShotCoordinate(
            previousEnemyGameBoardHitPositions,
            enemyGameBoard,
            coordinatesForAttack,
        );
        enemyGameBoard.receiveAttack(shotCoordinate);
    };

    const autoPlaceShip=function () {
        const firstPositionsOfAllGameboardRow=[0, 10, 20, 30, 40, 50, 60, 70, 80, 90];
        const fourRandomlyPickedPositions=[];
        const pickeARandomPosition= function () {
            return firstPositionsOfAllGameboardRow[
                Math.floor(Math.random() * firstPositionsOfAllGameboardRow.length)
            ];
        };
        for(let i=0;i<5;i+=1) {
            const randomlyPickedPosition=pickeARandomPosition();
            fourRandomlyPickedPositions.push(randomlyPickedPosition);
            firstPositionsOfAllGameboardRow.splice(
                firstPositionsOfAllGameboardRow.indexOf(randomlyPickedPosition),
                1,
            );
        }
        
        gameboard.placeShip("carrier", fourRandomlyPickedPositions[0]);
        gameboard.placeShip("battleship", fourRandomlyPickedPositions[1]+6);
        // 4 is the length of battleship
        gameboard.placeShip("destroyer", fourRandomlyPickedPositions[2]+3);
        // 3 is the length of destroyer
        gameboard.placeShip("submarine", fourRandomlyPickedPositions[3]+8);
        // 6 is a random number
        gameboard.placeShip("titanic", fourRandomlyPickedPositions[4]+12);
    };
    return { gameboard, attack, autoPlaceShip };
}; /*Ez a kódrészlet egy ai nevű factory function-t definiál, ami létrehoz egy
 AI játékost. Az AI játékosnak van egy gameboard nevű objektuma, ami egy játéktáblát 
 reprezentál, és ennek van egy placeShip metódusa, amivel hajókat lehet elhelyezni a játéktáblán.
  Emellett van egy attack metódusa, amivel az AI játékos tüzet nyithat a másik játékosra, valamint
   egy autoPlaceShip metódusa, amivel az AI játékos automatikusan elhelyezi a hajóit a saját játéktábláján. 
   Az ai factory function visszatér
 egy objektummal, ami tartalmazza a gameboard, attack és autoPlaceShip metódusokat.*/

const human = humanPlayer();
const computer = ai(); /*Ezek a kódrészletek két változót hoznak létre a játékos és a 
számítógép objektumokkal, amelyek később használva lesznek a játék során. A human változó 
a humanPlayer() függvény visszatérési értéke, amely egy játékos objektumot hoz létre, és a computer 
változó az ai() függvény visszatérési értéke, amely egy számítógépes játékos objektumot hoz létre. 
A human és a computer objektumoknak vannak 
tulajdonságaik és metódusaik, amelyek a játék logikáját valósítják meg.*/

const getHitScoreOfBothPlayer=function () {
    const humanHitPositionsArr = [];
    computer.gameboard.shipList.forEach((ship) => {
        ship.hitPositions.forEach((position) => {
            humanHitPositionsArr.push(position);
        });
    });
    const humanMissedHitCount = computer.gameboard.missedHits.length;

    const computerHitPositionsArr = [];
    human.gameboard.shipList.forEach((ship) => {
        ship.hitPositions.forEach((position) => {
            computerHitPositionsArr.push(position);
        });
    });
    const computerMissedHitCount = human.gameboard.missedHits.length;

    return {
        humanHitCount: humanHitPositionsArr.length,
        humanMissedHitCount,
        computerHitCount: computerHitPositionsArr.length,
        computerMissedHitCount,
    };
}; /*Ez a kód egy objektumot ad vissza, amely tartalmazza a játékosok találati
 és elhibázott találati számait. A humanHitPositionsArr tömbben tárolja azokat
  a pozíciókat, amelyekre a számítógép talált az ember játékos hajói közül. Ezután 
  hozzáadja az ember játékos elhibázott lövéseinek számát a humanMissedHitCount változóba.
   Hasonlóképpen, a computerHitPositionsArr tömbben tárolja az ember játékos találatait a 
   számítógép hajói közül, majd hozzáadja a számítógép elhibázott lövéseinek számát a 
   computerMissedHitCount változóhoz. A visszatérő objektum az emberi játékos 
és a számítógép által talált és elhibázott lövések számát tartalmazza*/




/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
(() => {

__webpack_require__.r(__webpack_exports__);
 var _gameLogic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./gameLogic */ "./src/gameLogic.js");
 var _dragDropLogic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dragDropLogic */ "./src/dragDropLogic.js");
/*Ez egy webpack bundle fájl eleje, amelyben az importált modulokat használják a kódban.
 Az első sor egy __webpack_exports__ objektumot hoz létre, amely a kódban definiált exportokat tárolja. 
 Az (() => { sor az IIFE (Immediately Invoked Function Expression) kezdetét jelöli, amelynek célja a modulok
     inicializálása és a függőségek feloldása. A következő sorokban a require függvény segítségével töltik 
     be a gameLogic és a dragDropLogic modulokat, majd ezen modulokban definiált változókat használják a 
     további kódban. 
    A __webpack_require__.r(__webpack_exports__) sor pedig az exports objektumot inicializálja*/




const howToModal = document.querySelector("#modal");// Az első három sor a modális ablakhoz kapcsolódó elemeket hivatkozza meg.
const howToModalCloseButton = document.querySelector("#close_how_to_modal");// Az első három sor a modális ablakhoz kapcsolódó elemeket hivatkozza meg.
const howToButton = document.querySelector(".how_to"); // Az első három sor a modális ablakhoz kapcsolódó elemeket hivatkozza meg.

howToButton.addEventListener("click", () => { // Az alábbi kód az "how to" gombra kattintásra megnyitja a modális ablakot.
    howToModal.showModal();
});

howToModalCloseButton.addEventListener("click", () => { // Az alábbi kód a modális ablak bezárására szolgál.
    howToModal.close();
});

const friendlyAreaGameboard = document.querySelector( // Az utolsó két sor a játékterületek elemét jelöli ki.
    "#friendly-area-gameboard",
);
const enemyAreaGameboard = document.querySelector("#enemy-area-gameboard"); // Az utolsó két sor a játékterületek elemét jelöli ki.

const createGameBoardDom = function (gameBoardContainerName) {
    const gridSize = 10;
    const gridSquare = 100;
    
    gameBoardContainerName.style.gridTemplateRows = `repeat(${ gridSize },1fr)`;
    
    gameBoardContainerName.style.gridTemplateColumns = `repeat(${ gridSize },1fr)`;
    const squareDiv = [];
    let loopCount = 1;
    let yAxis = 1;
    for (let i = 0; i < gridSquare; i += 1) {
        squareDiv[i] = document.createElement("div");
        squareDiv[i].setAttribute("data-index", `${ [i, yAxis] }`);
        if (loopCount === 10) {
            yAxis += 1;
            loopCount = 1;
        } else {
            loopCount += 1;
        }
        squareDiv[i].classList.add("square_div");
        gameBoardContainerName.appendChild(squareDiv[i]);
    }
}; /*A kód létrehoz egy játéktábla megjelenítést a DOM-ban, amely 10x10 négyzetből
 áll, a négyzeteket pedig egy grid-el rendezi el. A négyzetekhez hozzáad egy adat attribútumot,
  ami az adott négyzet pozícióját tartalmazza a játéktáblán, és osztályt állít be rájuk. 
Végül az összes négyzetet hozzáadja a megadott játéktábla konténerhez.*/

createGameBoardDom(friendlyAreaGameboard);
createGameBoardDom(enemyAreaGameboard);
/*Ezek a kódrészletek létrehozzák a játéktáblákat a HTML-ben megadott DOM 
elemekből (az friendlyAreaGameboard és az enemyAreaGameboard változók), és 
hozzáadják a megfelelő cellákat és eseménykezelőket azokhoz. A createGameBoardDom() függvény 
egy paraméterként kapott DOM elemet vesz át, majd létrehozza a játéktábla celláit, azok koordinátáit
 és hozzáadja a kattintás eseménykezelőt, amely meghívja a handleClickEvents() függvényt. Ez a függvény 
 felelős a 
játékos lövésének kezeléséért, amikor a játékos kattint egy cellára*/

(0,_dragDropLogic__WEBPACK_IMPORTED_MODULE_1__.addDragDropFeature)(_gameLogic__WEBPACK_IMPORTED_MODULE_0__.human);
/*z a kód hozzáadja a "drag and drop" funkciót a játéktáblához,
 amely lehetővé teszi, hogy a felhasználó húzza és ejtse a hajóit a táblára.
  A _dragDropLogic__WEBPACK_IMPORTED_MODULE_1__.addDragDropFeature függvény 
  visszatér egy olyan függvénnyel, amelyet a játékos objektummal kell meghívni, 
  hogy hozzáadhassa a "drag and drop" funkciót a játéktáblához. A kód használja
   az _gameLogic__WEBPACK_IMPORTED_MODULE_0__.human objektumot,
 hogy hozzáadja ezt a funkciót a felhasználó játéktáblájához.*/

const autoPlaceButton = document.querySelector("#auto_place"); // A gomb elem, ami az automatikus hajóhelyezést indítja
const shipContainer = document.querySelector("#all_ship_container"); // A div elem, ami az összes hajót tartalmazza a felhasználói felületen
const gameStartButton = document.querySelector("#start");  // A gomb elem, ami elindítja a játékot


const markShipsInTheDom = function () {
    _gameLogic__WEBPACK_IMPORTED_MODULE_0__.human.gameboard.shipList.forEach((ship) => {
        for (let i = 0; i < ship.shipLength; i += 1) {
            friendlyAreaGameboard.children[ship.coordinate + i].style.background =
        "#444444";
        }
    });
}; /*Ez a kód arra szolgál, hogy bejelölje a játékos hajóinak helyét a baráti 
területen a DOM-ban. A függvény végigmegy a játékos hajóin a játéklogikában tárolt
 hajólista segítségével, majd beállítja a megfelelő 
DOM elemek háttérszínét a "444444" színre, hogy jelölje a hajók helyét.*/

const autoPlaceShips = function () {
    _gameLogic__WEBPACK_IMPORTED_MODULE_0__.human.gameboard.placeShip("carrier", 14);
    _gameLogic__WEBPACK_IMPORTED_MODULE_0__.human.gameboard.placeShip("battleship", 34);
    _gameLogic__WEBPACK_IMPORTED_MODULE_0__.human.gameboard.placeShip("destroyer", 94);
    _gameLogic__WEBPACK_IMPORTED_MODULE_0__.human.gameboard.placeShip("submarine", 74);
    _gameLogic__WEBPACK_IMPORTED_MODULE_0__.human.gameboard.placeShip("titanic", 59);
    markShipsInTheDom();
    shipContainer.style.display = "none";
    gameStartButton.style.display = "block";
};
/*Ez a függvény az emberi játékos hajóinak automatikus elhelyezését
 végzi el az emberi játéktáblán. Konkrétan a függvény meghívja az
  placeShip() függvényt az öt hajóval, amelyeknek előre definiált helyük van az emberi játéktáblán. 
  Ezután a markShipsInTheDom() függvényt hívja meg, hogy megjelenítse ezeket a hajókat a DOM-ban, majd 
  eltávolítja 
a hajók elhelyezéséhez használt shipContainer elemet és megjeleníti a gameStartButton gombot.*/
autoPlaceButton.addEventListener("click", autoPlaceShips); /*Ez a kód egy eseménykezelőt
 hoz létre a "autoPlaceButton" gombra, és amikor a 
gombra kattintanak, akkor meghívja az "autoPlaceShips" függvényt.*/

const markHitUnhit = function (enemy, enemyGameboardDom) {
    enemy.gameboard.shipList.forEach((ship) => {
        ship.hitPositions.forEach((position) => {
            
            enemyGameboardDom.children[position].style.background = "#F93943";
        });
    });
    enemy.gameboard.missedHits.forEach((missedHitPosition) => {
    
        enemyGameboardDom.children[missedHitPosition].style.background = "#05B2DC";
    });
}; /*Ez a kód a játékmezőn megjeleníti az ellenfél találatokat és elhibázott lövéseit. 
A markHitUnhit függvény megkapja az ellenfél objektumát és a hozzá tartozó DOM elemet, majd 
végigmegy az összes hajón és megjeleníti a találatokat a 
hajóra, és megjeleníti az elhibázott lövéseket a megfelelő helyeken a játékmezőn.*/

const itIsAiTurn = function () {
    _gameLogic__WEBPACK_IMPORTED_MODULE_0__.computer.attack(_gameLogic__WEBPACK_IMPORTED_MODULE_0__.human.gameboard);
    markHitUnhit(_gameLogic__WEBPACK_IMPORTED_MODULE_0__.human, friendlyAreaGameboard);
}; /*z a kód felelős az AI játékos lépésének végrehajtásáért a játék során. Az itIsAiTurn 
függvény meghívja a computer.attack függvényt, ami az AI játékos támadását kezeli a emberi játékos 
játékterületén, majd a markHitUnhit függvényt hívja meg, ami a találatok és elhibázott 
lövések jelöléséért felelős a emberi játékos játékterületén (friendlyAreaGameboard-on).*/

const checkWinner = function () {
    const allComputerShipSunk = _gameLogic__WEBPACK_IMPORTED_MODULE_0__.computer.gameboard.areAllShipSunk();
    const allHumanShipSunk = _gameLogic__WEBPACK_IMPORTED_MODULE_0__.human.gameboard.areAllShipSunk();
    if (allComputerShipSunk) {
        return "Te vagy ";
    } else if (allHumanShipSunk) {
        return "Gép";
    }
    return false;
}; /*Ez a kód ellenőrzi, hogy van-e nyertes a játékban, és visszaadja a nyertes
 játékos nevét. Először megnézi, hogy az összes AI hajó elsüllyedt-e, és ha igen, akkor 
 visszaadja a "you" szöveget, ami azt jelzi, hogy az emberi játékos nyert. Ha az összes emberi
  hajó elsüllyedt, akkor visszaadja az "ai" 
szöveget, ami azt jelzi, hogy az AI nyert. Ha nincs nyertes, akkor false értéket ad vissza.*/

const removeAllEventListenerInComputerGameboard = function () {
    enemyAreaGameboard.childNodes.forEach((child) => {
        child.removeEventListener("click", handleClickEvents);
    });
}; /*Ez a kód az összes eseményfigyelő eltávolítja az ellenfél táblázat gyermekelemeiről.*/

const showScore = function () {
    const score = (0,_gameLogic__WEBPACK_IMPORTED_MODULE_0__.getHitScoreOfBothPlayer)();
    const humanScoreCard = document.querySelector("#human_score_card");
    const humanMissedHitCount = humanScoreCard.children[0];
    const humanHitCount = humanScoreCard.children[1];
    humanMissedHitCount.textContent = `Elhibázott lövések: ${ score.humanMissedHitCount }`;
    humanHitCount.textContent = `Pontok: ${ score.humanHitCount }`;

    const computerScoreCard = document.querySelector("#ai_score_card");
    const computerMissedHitCount = computerScoreCard.children[0];
    const computerHitCount = computerScoreCard.children[1];
    computerMissedHitCount.textContent = `Elhibzott lövések: ${ score.computerMissedHitCount }`;
    computerHitCount.textContent = `Pontok: ${ score.computerHitCount }`;
};
/*Ez a kód frissíti a játékosok pontszámát és elhibázott lövéseinek számát mutató HTML
 elemek tartalmát a megfelelő értékekkel. Először lekéri a pontszámokat és elhibázott lövések 
 számát a getHitScoreOfBothPlayer függvény segítségével. Majd ezeket az értékeket beállítja az
  emberi és AI játékosok pontszámát 
és elhibázott lövéseit mutató HTML elemekbe, hogy azok megjelenjenek a felhasználónak a képernyőn.*/

const handleClickEvents = function () {
    const targetIndex = parseInt(this.dataset.index.split(",")[0]);
    _gameLogic__WEBPACK_IMPORTED_MODULE_0__.computer.gameboard.receiveAttack(targetIndex);
    markHitUnhit(_gameLogic__WEBPACK_IMPORTED_MODULE_0__.computer, enemyAreaGameboard);
    itIsAiTurn();
    showScore();
    const winner = checkWinner();
    if (winner) {
        alert(`${winner} a győztes!`);
        removeAllEventListenerInComputerGameboard();

        const restartButton = document.createElement("button");
        restartButton.innerText = "Új játék";
        restartButton.addEventListener("click", function () {
            location.reload();
        });
        document.body.appendChild(restartButton);
    }
};/*Ez a kód egy eseménykezelő függvény, amely az ellenfél játékterének egy 
cellájára kattintás esetén aktiválódik. Az eseménykezelő függvény által meghívott 
függvények végzik el az AI játékos támadását az emberi játékos játékterén, megjelölik a találatot
 vagy a kihagyást az AI játékos játékterén, és növelik az AI játékos pontszámát. A kód ellenőrzi,
 hogy van-e győztes, és ha van, akkor meghívja a megfelelő függvényeket a játék befejezéséhez.*/

const addEventListenerToAiGameBoard = function () {
    enemyAreaGameboard.childNodes.forEach((child) => {
        child.addEventListener("click", handleClickEvents, { once: true });
    });
}; /*Ez a kód minden egyes gyermek elemre (cellára) az ellenfél játéktáblán, 
hozzáad egy eseményfigyelőt a 'click' eseményhez, és az eseményfigyelő a 
'handleClickEvents' függvényt futtatja egyszer. Ez azt jelenti, hogy miután az adott cellát egyszer 
kattintották, az eseményfigyelő eltávolítása a celláról, így nem lehet többször kattintani.*/

const aiDomContainer = document.querySelector("#ai_container"); /*#ai_container id-jú elemet keres a
 DOM-ban, és eltárolja az aiDomContainer változóban.*/
const scoreCard = document.querySelector("#score_card_container");/*#score_card_container id-jú 
elemet keres a DOM-ban, és eltárolja a scoreCard változóban.*/
const playGame = function (gameStartButton) {
    // eslint-disable-next-line no-param-reassign
    gameStartButton.style.display = "none";
    aiDomContainer.style.display = "block";
    scoreCard.style.display = "flex";
    _gameLogic__WEBPACK_IMPORTED_MODULE_0__.computer.autoPlaceShip();
    addEventListenerToAiGameBoard();
    autoPlaceButton.style.display = "none"; // hozzáadott sor
	
};



/*A playGame függvényt definiálja, amely egy click eseményre (az átadott gameStartButton gombra) 
hívódik meg. Az első sor eltávolítja a gombot az oldalról, majd a következő két sor megjeleníti az 
AI játéktáblát és a pontszámkártyát. A függvény továbbá meghívja az autoPlaceShip függvényt a computer 
objektumon, ami automatikusan elhelyezi a hajókat a gépi játékos játéktábláján. Végül hívódik meg a 
addEventListenerToAiGameBoard függvény,
 ami eseménykezelőket regisztrál az AI játéktáblának a kattintások kezeléséhe*/

const startGameButton = document.querySelector("#start");
startGameButton.addEventListener("click", (e) => {
    playGame(e.target);
}); /*Ez a kód egy HTML oldalon található gombra való kattintás eseménykezelőjét
 definiálja. Amikor a felhasználó rákattint a gombra, az eseménykezelő meghívja a 
 playGame függvényt az esemény kiváltó elemmel (azaz a gombbal) paraméterként.*/

})();

/******/ })()
;
