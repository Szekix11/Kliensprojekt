
import { human, computer, getHitScoreOfBothPlayer } from "./gameLogic";
import { addDragDropFeature } from "./dragDropLogic"; /*Importálja a szükséges függvényeket és 
modulokat a "gameLogic" és a "dragDropLogic" fájlokból:*/

const howToModal = document.querySelector("#modal");
const howToModalCloseButton = document.querySelector("#close_how_to_modal");
const howToButton = document.querySelector(".how_to");
/*Kiválasztja a HTML dokumentumban található elemeket az id alapján*/

howToButton.addEventListener("click", () => {
    howToModal.showModal();
});

howToModalCloseButton.addEventListener("click", () => {
    howToModal.close();
}); /*A "howToModalCloseButton" gombra kattintva bezárja az "howToModal" modális ablakot.*/

const friendlyAreaGameboard = document.querySelector(
    "#friendly-area-gameboard",
);
const enemyAreaGameboard = document.querySelector("#enemy-area-gameboard");

const createGameBoardDom = function (gameBoardContainerName) {
    const gridSize = 10;
    const gridSquare = 100;

    gameBoardContainerName.style.gridTemplateRows = `repeat(${ gridSize },1fr)`;

    gameBoardContainerName.style.gridTemplateColumns = `repeat(${ gridSize },1fr)`;
    const squareDiv = [];
    let loopCount = 1;
    let yAxis = 1;
    for (let i = 0; i < gridSquare; i += 1) {
        squareDiv[i] = document.createElement("div");
        squareDiv[i].setAttribute("data-index", `${ [i, yAxis] }`);
        if (loopCount === 10) {
            yAxis += 1;
            loopCount = 1;
        } else {
            loopCount += 1;
        }
        squareDiv[i].classList.add("square_div");
        gameBoardContainerName.appendChild(squareDiv[i]);
    }
};  /*Ez a kódrészlet egy játéktáblát hoz létre a HTML DOM-ban a megadott gameBoardContainerName 
nevű elemen belül. A játéktábla 10x10-es méretű, összesen 100 négyzetrácsos cellából áll. A for ciklus
 létrehozza az összes cellát, hozzáadja a megfelelő osztályokat és adattagokat, majd hozzárendeli azokat a
  gameBoardContainerName elemhez. Az elkészült 
játéktábla használható a hajók elhelyezésére és a játékmenet során történő lövések megjelenítésére.*/

createGameBoardDom(friendlyAreaGameboard); /*createGameBoardDom függvény meghívásával 
létrehoz egy játéktáblát a friendlyAreaGameboard HTML elemen belül.*/
createGameBoardDom(enemyAreaGameboard); /*sor a createGameBoardDom 
függvény meghívásával létrehoz egy játéktáblát az enemyAreaGameboard HTML elemen belül.*/

addDragDropFeature(human);
/*addDragDropFeature függvény meghívásával hozzáadja a húzható és dobható funkciókat
 az emberi játékos hajóira. Ez lehetővé teszi, hogy az emberi játékos kattintson
 és húzza a hajókat a saját játéktábláján, majd dobja őket a megfelelő helyre.*/

const autoPlaceButton = document.querySelector("#auto_place");
const shipContainer = document.querySelector("#all_ship_container");
const gameStartButton = document.querySelector("#start");
/*    autoPlaceButton: Az autoPlaceButton a DOM-ban található gombot jelöli meg, amelyet a felhasználó 
megnyomhatja a hajók automatikus elhelyezéséhez a játéktáblán.
    shipContainer: Az shipContainer a DOM-ban található konténer elemet jelöli meg, amely
     tartalmazza a hajókat, amelyeket a felhasználó elhelyezhet a játéktáblán.
    gameStartButton: Az gameStartButton a DOM-ban található gombot jelöli meg, amelyet a 
    felhasználó megnyomhatja a játék indításához.*/

const markShipsInTheDom = function () {
    human.gameboard.shipList.forEach((ship) => {
        for (let i = 0; i < ship.shipLength; i += 1) {
            friendlyAreaGameboard.children[ship.coordinate + i].style.background =
        "#444444";
        }
    });
}; /*Ez a kód részlet a játékteret reprezentáló DOM elemekben 
megjeleníti a felhasználó hajóinak pozícióit. A human.gameboard.shipList 
ciklusában végigiterál a felhasználó hajóin, majd mindegyik hajón belül a 
hajóhosszúság szerint végigiterálva beállítja a megfelelő DOM elemek hátterét. 
Ezáltal a felhasználó hajói világosszürke háttérszínnel jelennek meg a játéktéren.*/

const autoPlaceShips = function () {
    human.gameboard.placeShip("carrier", 14);
    human.gameboard.placeShip("battleship", 34);
    human.gameboard.placeShip("destroyer", 94);
    human.gameboard.placeShip("submarine", 74);
    human.gameboard.placeShip("titanic", 64);
    markShipsInTheDom();
    shipContainer.style.display = "none";
    gameStartButton.style.display = "block";
};
/*Ez a kód részlet a játékos hajóinak automatikus elhelyezését végzi el a 
játékterületén, majd a hajók elhelyezését jelölő színek megjelenítése a DOM-ban.
 A placeShip() metódus meghívásával hat hajót helyez el a játéktéren, majd a markShipsInTheDom() 
 metódus meghívásával jelöli a hajók helyét a DOM-ban. Végül a shipContainer konténer eltűntetése 
és az gameStartButton gomb megjelenítése a felhasználó számára, hogy elkezdhesse a játékot.*/
autoPlaceButton.addEventListener("click", autoPlaceShips);
/*Ez a kódrészlet egy eseményfigyelőt állít be az "autoPlaceButton" gombra, amely 
akkor hívja meg az "autoPlaceShips" függvényt, ha a gombra kattintanak. Az "autoPlaceShips" 
függvény az emberi játékos hajóit véletlenszerűen elhelyezi a játéktáblán, majd megjeleníti 
az indítás gombot, és elrejti a hajók kiválasztásához szükséges UI elemeket.*/

const markHitUnhit = function (enemy, enemyGameboardDom) {
    enemy.gameboard.shipList.forEach((ship) => {
        ship.hitPositions.forEach((position) => {
            
            enemyGameboardDom.children[position].style.background = "#F93943";
        });
    });
    enemy.gameboard.missedHits.forEach((missedHitPosition) => {
  
        enemyGameboardDom.children[missedHitPosition].style.background = "#05B2DC";
    });
}; /*Ez a kódrészlet a megadott ellenfél játékterületén jelöli meg az összes találatot 
és elhibázott lövést a hajóira. Az ellenfél hajóit reprezentáló hajók listáján végighaladva,
 az összes találat pozícióját beállítja a hátteret a DOM-ban, hogy pirosra
 változzon, és az összes elhibázott lövés helyét is megjelöli, hogy kékre változzon.*/

const itIsAiTurn = function () {
    computer.attack(human.gameboard);
    markHitUnhit(human, friendlyAreaGameboard);
}; /*Ez a kódrészlet az ellenfél gép (computer) következését kezeli. 
A computer megtámadja az emberi játékos (human) játéktábláját a attack() 
függvénnyel, majd a markHitUnhit() függvény segítségével megjelöli a találatokat és a 
nem találatokat a baráti játéktábla DOM-jában (friendlyAreaGameboard).*/

const checkWinner = function () {
    const allComputerShipSunk = computer.gameboard.areAllShipSunk();
    const allHumanShipSunk = human.gameboard.areAllShipSunk();
    if (allComputerShipSunk) {
        return "you";
    } else if (allHumanShipSunk) {
        return "ai";
    }
    return false;
}; /*Ez a kód a játék végén ellenőrzi, hogy van-e nyertes. Először ellenőrzi, 
hogy az összes számítógépes hajó elsüllyedt-e a computer.gameboard.areAllShipSunk() függvénnyel.
 Ha igen, akkor a játékos nyert. Ha nem, akkor ellenőrzi, hogy az összes emberi hajó elsüllyedt-e a 
 human.gameboard.areAllShipSunk() függvénnyel. Ha igen, akkor az AI nyert. Ha mindkét játékosnak van 
 még hajója, akkor nincs nyertes, és a függvény false értéket ad vissza.*/

const removeAllEventListenerInComputerGameboard = function () {
    enemyAreaGameboard.childNodes.forEach((child) => {
        child.removeEventListener("click", handleClickEvents);
    });
}; /*Ez a kód eltávolítja az összes eseménykezelőt az 
ellenfél játéktábláján a click esemény típushoz kapcsolódóan.*/

const showScore = function () {
    const score = getHitScoreOfBothPlayer();
    const humanScoreCard = document.querySelector("#human_score_card");
    const humanMissedHitCount = humanScoreCard.children[0];
    const humanHitCount = humanScoreCard.children[1];
    humanMissedHitCount.textContent = `Missed Hits: ${ score.humanMissedHitCount }`;
    humanHitCount.textContent = `Hits: ${ score.humanHitCount }`;

    const computerScoreCard = document.querySelector("#ai_score_card");
    const computerMissedHitCount = computerScoreCard.children[0];
    const computerHitCount = computerScoreCard.children[1];
    computerMissedHitCount.textContent = `Missed Hits: ${ score.computerMissedHitCount }`;
    computerHitCount.textContent = `Hits: ${ score.computerHitCount }`;
}; /*Ez a kód a játékosok találatainak és elhibázásainak a számát jeleníti 
meg az eredménytáblán a felhasználó és a számítógép számára. A getHitScoreOfBothPlayer() 
függvény visszaadja a találati pontszámokat, majd ezeket az értékeket felhasználják a textContent 
tulajdonság beállításához és megjelenítéséhez az eredménytáblán.*/

const handleClickEvents = function () {
    const targetIndex = parseInt(this.dataset.index.split(",")[0]);
    computer.gameboard.receiveAttack(targetIndex);
    markHitUnhit(computer, enemyAreaGameboard);
    itIsAiTurn();
    showScore();
    const winner = checkWinner();
    if (winner) {
        alert(`${ winner } won the game`);
        removeAllEventListenerInComputerGameboard();
    }
}; /*Ez a kódrészlet kezeli a kattintási eseményeket az ellenséges játéktáblán. 
A kattintott mező indexét kinyeri a "data-index" attribútumból, majd meghívja az AI 
"receiveAttack" függvényét a kiválasztott mező indexével. Ezután az "markHitUnhit" függvénnyel 
megjelöli az AI által támadott hajókat, majd meghívja az "itIsAiTurn" függvényt, hogy az AI támadjon. 
Végül a "showScore" függvénnyel frissíti a pontszámot, majd ellenőrzi, hogy van-e győztes, és megjeleníti 
a megfelelő üzenetet az alert paranccsal. Ha van győztes, eltávolítja az összes eseménykezelőt az 
AI játéktábláról a "removeAllEventListenerInComputerGameboard" függvény segítségével.*/

const addEventListenerToAiGameBoard = function () {
    enemyAreaGameboard.childNodes.forEach((child) => {
        child.addEventListener("click", handleClickEvents, { once: true });
    });
}; /*Ez a kód hozzáad egy eseménykezelőt minden egyes ellenséges 
területi játéktábla elemhez, amely az AI tábláját jelöli. Amikor az esemény kattintást érzékel, akkor a függvény elindítja a szükséges logikát az AI támadásához és annak eredményeinek megjelenítéséhez az emberi táblán. A "once: true" opció azt jelenti, hogy a kattintás után az eseménykezelő eltávolításra 
kerül az elemről, így csak egy lépést engedélyez a felhasználónak a lépésre.*/

const aiDomContainer = document.querySelector("#ai_container");
const scoreCard = document.querySelector("#score_card_container"); /*Kiválasztja a HTML dokumentumban található 
"ai_container" és "score_card_container" id-jú elemeket:*/
const playGame = function (gameStartButton) {   
    /*Létrehoz egy "playGame" nevű függvényt, amelynek van egy "gameStartButton" 
    paramétere. Az "eslint-disable-next-line no-param-reassign" 
    megjegyzés azért van ott, hogy figyelmen kívül hagyja az eslint szabályait, 
    amelyek azt tiltják, hogy az argumentumot újra definiáljuk.*/
    gameStartButton.style.display = "none"; /* függvény tartalma a következő:
    Elrejti a "gameStartButton" gombot*/
    aiDomContainer.style.display = "block"; //Megjeleníti az "ai_container" és "score_card_container" elemeket
    scoreCard.style.display = "flex"; //Megjeleníti az "ai_container" és "score_card_container" elemeket
    computer.autoPlaceShip(); /*Az ellenfél játéktábláján automatikusan elhelyezi a hajóit a "computer.autoPlaceShip()" függvénnyel*/
    addEventListenerToAiGameBoard(); /*Hozzáad eseményfigyelőket az ellenfél játéktáblájához a "addEventListenerToAiGameBoard()" függvénnyel*/
};

const startGameButton = document.querySelector("#start"); /*Kiválasztja a HTML dokumentumban található
 "start" id-jú gombot*/
startGameButton.addEventListener("click", (e) => {  /*Eseménykezelőt hoz létre a "startGameButton" gombra 
kattintva, amely meghívja a "playGame" függvényt*/
    playGame(e.target);  /*A "playGame" függvény a játékot indítja el a játékosok és a számítógép között, 
    az "e.target" pedig a kattintás forrásának a gombot jelöli. A "click" eseményt 
    figyeli, ami azt jelenti, hogy amikor a felhasználó rákattint a gombra, elindul a játék.*/
});

