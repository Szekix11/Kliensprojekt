const ship= function (shipname, coordinate) {
    let shipLength;
    switch (shipname) {
    case "carrier":
        shipLength = 5;
        break;
    case "battleship":
        shipLength = 4;
        break;
    case "destroyer":
        shipLength = 3;
        break;
    case "submarine":
        shipLength = 2;
        break;
        case "titanic":
            shipLength = 1;
            break;
    }
    const hitPositions = [];
    const hit=function (hitCoordinate) {
        hitPositions.push(hitCoordinate);
    };
    const isSunk=function () {
        if (hitPositions.length === shipLength) {
            return true;
        }
        return false;
    };
    return { coordinate, shipLength, hitPositions, hit, isSunk };
};
/*Ez a kód egy ship objektum-ot definiál, amelyet a hajók leírására használnak. 
Az objektum létrehozásakor a hajó hosszát határozzák meg a neve alapján, majd inicializálnak egy 
üres tömböt, amely tárolja a hajó találati pozícióit. Az objektum két metódust tartalmaz, az egyik hit(), 
amely hozzáadja a találat pozícióját a tömbhöz, a másik pedig isSunk(), amely megvizsgálja, hogy a hajó 
elsüllyedt-e (azaz eltalálták-e az összes részét). Az objektum végül egy objektum literál segítségével kerül 
visszaadásra,
 amely tartalmazza az objektum létrehozásakor inicializált adatokat és metódusokat.*/

const gameBoard=function () {
    const shipList = [];
    const placeShip=function (shipname, coordinate) {
        shipList.push(ship(shipname, coordinate));
    };
    const missedHits = [];
    const receiveAttack=function (hitCoordinate) {
        for (let i = 0; i < shipList.length; i+=1) {
            if (
                hitCoordinate >= shipList[i].coordinate &&
        hitCoordinate < shipList[i].coordinate + shipList[i].shipLength
            ) {
                shipList[i].hit(hitCoordinate);
                break;
            } else if (i === shipList.length - 1) {
                
                missedHits.push(hitCoordinate);
            }
        }
    };
    const areAllShipSunk=function () {
        return shipList.every((ship) => ship.isSunk());
    };
    return { shipList, placeShip, receiveAttack, missedHits, areAllShipSunk };
};
/*Ez a kód egy játéktáblát reprezentáló objektumot definiál. A játéktábla tartalmazza a 
rajta elhelyezett hajókat, az eltalált koordinátákat és a lekötött hajókat. Az objektum három fő 
metódust tartalmaz:

    placeShip: Ez a metódus a játéktáblára helyezi a megadott hajót az adott koordinátán.
    receiveAttack: Ez a metódus az adott koordinátára adott lövést kezeli. Ellenőrzi, hogy a 
    lövés talált-e valamelyik hajóra, és ha igen, akkor 
    elmenti az eltalált koordinátát a megfelelő hajó objektumban. Ha nem talált, akkor a lekötött 
    lövések közé tartozik.
    areAllShipSunk: Ez a metódus ellenőrzi, hogy az összes hajó a játéktáblán el van-e süllyesztve. 
    A metódus visszatérési értéke true lesz, ha minden hajó elsüllyedt, ellenkező esetben false.*/
const humanPlayer=function () {
    const gameboard = gameBoard();
    const attack=function (enemyGameBoard, attackCoordinate) {
        enemyGameBoard.receiveAttack(attackCoordinate);
    };
    return { gameboard, attack };
};
/*Ez a kód egy humán játékost reprezentáló objektumot hoz létre,
 ami tartalmaz egy játéktáblát (gameboard) és egy attack függvényt,
  amivel a játékos támadást indíthat az ellenfél játéktáblája ellen egy 
  adott koordinátán (attackCoordinate). Az attack függvényben meghívódik 
  az ellenfél játéktáblájának receiveAttack függvénye az adott koordinátával, 
aminek hatására az ellenfél hajóit találat éri, vagy nem talál.*/
const returnLastSuccessfulHitPositionOfEnemyGameboard=function (
    previousEnemyGameBoardHitPositions,
    enemyGameBoard,
) {
    let updatedEnemyGameboardHitPositions = [];
    enemyGameBoard.shipList.forEach((ship) => {
        updatedEnemyGameboardHitPositions =
      updatedEnemyGameboardHitPositions.concat(ship.hitPositions);
    });
    const lastHitPositionStr = updatedEnemyGameboardHitPositions
        
        .filter((position) => !previousEnemyGameBoardHitPositions.includes(position))
        .toString();
    if (
        updatedEnemyGameboardHitPositions.length >
    previousEnemyGameBoardHitPositions.length
    ) {
    
        const lastHitPosition = parseInt(lastHitPositionStr);
        previousEnemyGameBoardHitPositions.push(lastHitPosition);
        return lastHitPosition;
    }
    return false; 

};
/*Ez a kód egy függvényt definiál returnLastSuccessfulHitPositionOfEnemyGameboard néven, 
ami két argumentumot vár: previousEnemyGameBoardHitPositions és enemyGameBoard.
 A függvény visszatérési értéke vagy az utolsó sikeres támadás helye (egész szám), vagy 
 false, ha az utolsó támadás sikertelen volt.

A függvény először végigmegy az ellenséges játéktábla hajóin, 
és összegyűjti az összes találatot a hitPositions tömbökben. Ezután
 a függvény meghatározza az utolsó találatot, amelyet az előző támadáskor még
  nem értek el az enemyGameBoard-on, majd ezt az értéket visszaadja, ha az utolsó támadás sikeres volt.
 Ha az utolsó támadás nem volt sikeres, akkor a függvény false értékkel tér vissza.*/

const calculateShotCoordinate=function (
    previousEnemyGameBoardHitPositions,
    enemyGameBoard,
    coordinatesForAttack,
) {
    const lastHitPositionOfEnemyGameboard =
    returnLastSuccessfulHitPositionOfEnemyGameboard(
        previousEnemyGameBoardHitPositions,
        enemyGameBoard,
    );
    const coordinatesForAttackIncludeNextHit = coordinatesForAttack.includes(
        lastHitPositionOfEnemyGameboard + 1,
    );
    let shotCoordinate;

    if (lastHitPositionOfEnemyGameboard && coordinatesForAttackIncludeNextHit) {
    
        shotCoordinate = lastHitPositionOfEnemyGameboard + 1;
        coordinatesForAttack.splice(
            coordinatesForAttack.indexOf(shotCoordinate),
            1,
        );
        return shotCoordinate;
    }
    shotCoordinate =
      coordinatesForAttack[
          Math.floor(Math.random() * coordinatesForAttack.length)
      ];
    coordinatesForAttack.splice(
        coordinatesForAttack.indexOf(shotCoordinate),
        1,
    );
    return shotCoordinate;

};
/*Ez a kód egy koordináta kiválasztására szolgál az ellenfél játéktábláján. 
A kódban meg van adva egy lista lehetséges koordinátákkal, amelyek közül kiválaszt 
egyet véletlenszerűen, ha az előző lövés nem talált el ellenfél hajójába. Ha az előző 
lövés eltalálta az ellenfél hajóját, akkor a kód az utolsó találat utáni következő koordinátát 
választja ki a lehetséges koordináták listájából.
 Ezt a kódot általában az ellenfél hajóinak eltalálásához használják egy játékos által.*/

const ai=function () {
    const gameboard = gameBoard();
    const gameBoardSize = 100;
    const coordinatesForAttack = [];
    for (let i = 0; i < gameBoardSize; i+=1) {
        coordinatesForAttack.push(i);
    }
    const previousEnemyGameBoardHitPositions = [];

    const attack=function (enemyGameBoard) {
        const shotCoordinate = calculateShotCoordinate(
            previousEnemyGameBoardHitPositions,
            enemyGameBoard,
            coordinatesForAttack,
        );
        enemyGameBoard.receiveAttack(shotCoordinate);
    };

    const autoPlaceShip=function () {
        const firstPositionsOfAllGameboardRow=[0, 10, 20, 30, 40, 50, 60, 70, 80, 90];
        const fourRandomlyPickedPositions=[];
        const pickeARandomPosition= function () {
            return firstPositionsOfAllGameboardRow[
                Math.floor(Math.random() * firstPositionsOfAllGameboardRow.length)
            ];
        };
        for(let i=0;i<5;i+=1) {
            const randomlyPickedPosition=pickeARandomPosition();
            fourRandomlyPickedPositions.push(randomlyPickedPosition);
            firstPositionsOfAllGameboardRow.splice(
                firstPositionsOfAllGameboardRow.indexOf(randomlyPickedPosition),
                1,
            );
        }
        
        gameboard.placeShip("carrier", fourRandomlyPickedPositions[0]);
        gameboard.placeShip("battleship", fourRandomlyPickedPositions[1]+6);
        // 4 is the length of battleship
        gameboard.placeShip("destroyer", fourRandomlyPickedPositions[2]+3);
        // 3 is the length of destroyer
        gameboard.placeShip("submarine", fourRandomlyPickedPositions[3]+8);
        // 6 is a random number
        gameboard.placeShip("titanic", fourRandomlyPickedPositions[4]+10);
    };
    return { gameboard, attack, autoPlaceShip };
};
/*Ez a kód az AI játékost implementálja egy hajózási játékhoz. Az ai függvény visszatér egy 
objektummal, amely három tulajdonságot tartalmaz:

    gameboard: egy játékteret reprezentáló objektum, amelyen az AI játékos hajóit helyezi 
    el és ahol a találatait tárolja;
    attack: egy függvény, amelynek az ellenfél játékterét kell megadni paraméterként, és ami 
    egy véletlenszerű vagy számított lövési koordinátát végrehajt az ellenfél játékterén;
    autoPlaceShip: egy függvény, amely véletlenszerűen elhelyezi az AI játékos hajóit a saját 
    játékterén.*/

const human = humanPlayer();
const computer = ai();

const getHitScoreOfBothPlayer=function () {
    const humanHitPositionsArr = [];
    computer.gameboard.shipList.forEach((ship) => {
        ship.hitPositions.forEach((position) => {
            humanHitPositionsArr.push(position);
        });
    });
    const humanMissedHitCount = computer.gameboard.missedHits.length;

    const computerHitPositionsArr = [];
    human.gameboard.shipList.forEach((ship) => {
        ship.hitPositions.forEach((position) => {
            computerHitPositionsArr.push(position);
        });
    });
    const computerMissedHitCount = human.gameboard.missedHits.length;

    return {
        humanHitCount: humanHitPositionsArr.length,
        humanMissedHitCount,
        computerHitCount: computerHitPositionsArr.length,
        computerMissedHitCount,
    };
};
/*Ez a kód a játék végén kiértékeli, hogy mennyi találat 
és hibás lövés volt mind a humán, mind a számítógép játékos részéről,
 majd visszaadja ezeket az értékeket egy objektum formájában. A függvény 
 először létrehoz két üres tömböt az emberi és számítógép játékos találatainak 
 tárolására, majd végigmegy az összes hajón mindkét játékos játékterén, és minden találat
  esetén hozzáadja a találat pozícióját a megfelelő tömbhöz. Ezután megszámolja mindkét játékos hibás
 lövéseinek számát, majd visszaadja ezeket az értékeket az előbb említett objektumban*/
//
export { ship, gameBoard, human, computer, humanPlayer, ai, getHitScoreOfBothPlayer };
/*Ez a kód exportál néhány objektumot és függvényt az aktuális modulból. Az export kulcsszóval lehet elérni, 
és az {} között felsorolt elemeket exportálja. Ezen a ponton a következő elemeket exportálja:

    ship: egy konstruktort, amely egy hajó objektumot hoz létre, amelynek tulajdonságai közé tartozik a 
    hossz, a találati pozíciók és az elsüllyedt státusz.
    gameBoard: egy konstruktort, amely egy játéktábla objektumot hoz létre, amelynek tulajdonságai közé
     tartozik a hajók listája, a találati és a kihagyott lövések pozíciói.
    human: egy játékost jelölő objektum, amelynek tulajdonságai közé tartozik a neve, a játéktáblája és 
    az attack metódusa.
    computer: egy játékost jelölő objektum, amelynek tulajdonságai közé tartozik az attack metódusa és 
    az autoPlaceShip metódusa.
    humanPlayer: egy objektum, amely a human objektumot és annak metódusait tartalmazza.
    ai: egy függvény, amely létrehoz egy AI játékost, aki rendelkezik egy játéktáblával, az attack és 
    az autoPlaceShip metódusokkal.
    getHitScoreOfBothPlayer: egy függvény, amely kiszámolja mindkét játékos találatainak számát és az
     elhibázott lövések számát.*/