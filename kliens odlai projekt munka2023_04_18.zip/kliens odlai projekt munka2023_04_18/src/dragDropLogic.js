/* eslint-disable max-len */
const addDragDropFeature=function (human) {
    const allDraggableDivs = document.querySelectorAll(".draggable");
    allDraggableDivs.forEach((div) => {
        for (let i = 0; i < div.children.length; i+=1) {
            div.children[i].addEventListener("mousedown", (e) => {
               
                div.dataset.index = e.target.dataset.index; 
            });
        }
    });  
    /*Ez a függvény az egérdrag esemény (dragstart) kezelője, amely akkor fut le, amikor a felhasználó 
    elkezdi húzni az egérrel az adott hajót (shipBeingDragged). A függvény által végzett tevékenységek a következők:

    Először eltárolja a hajót, amelyet elhúztak, a shipBeingDragged változóban.
    Meghatározza a hajó pozícióját az egérrel való érintkezésnél (positionOfMouseOnTheShip), amelyet az 
    adott hajó data-index attribútuma határoz meg.
    Meghatározza a hajó hosszát (lengthOfTheShip), amelyet szintén a hajó data-shiplength attribútuma 
    határoz meg.
    Elmenti a hajó azonosítóját (shipName) az id attribútumból.
    Végül az összes fenti adatot egy tömbbe helyezi (transferData), majd ezt a tömböt JSON formátumban 
    eltárolja a ship-data adatként (setData) az esemény (e.dataTransfer) adataiban.
    Ez a függvény tehát az egérdrag esemény kezelőjeként az adott hajó pozícióját, hosszát és azonosítóját 
    tárolja, majd ezeket adatként továbbítja a drop eseményhez kapcsolódó kezelőnek. */

    const dragstart=function (e) {
        const shipBeingDragged = e.target;
        const positionOfMouseOnTheShip = shipBeingDragged.dataset.index;
        const lengthOfTheShip = shipBeingDragged.dataset.shiplength;
        const shipName = shipBeingDragged.id;
        const transferData = [positionOfMouseOnTheShip, lengthOfTheShip, shipName];
        e.dataTransfer.setData("ship-data", JSON.stringify(transferData));
    };
     /* Ez a kód egy olyan függvényt határoz meg dragstart, amely egy paramétert vesz fel e. 
     Ezt a funkciót általában az esemény eseményfigyelőjeként használják dragstart. 
     Amikor a felhasználó elkezdi húzni egy elemet, ez a funkció kivon néhány adatot a húzott 
     elemről, például a pozícióját, hosszát és azonosítóját, és ezeket az adatokat egy tömbben tárolja.
     transferData. Ezeket az adatokat ezután 
     JSON-karakterláncként szerializálják, ésdataTransfer.setData()módszer.*/
    const dragEnter=function (e) {
        e.preventDefault();
    };
    /*Az dragEnter függvény meghívódik, amikor egy húzható elem bejut egy 
    célélem területére. Az első dolog, amit a függvény tesz, az az esemény alapértelmezett
     működésének megakadályozása (preventDefault). Ez azt jelenti, hogy az esemény további 
     alapértelmezett feldolgozása nem történik meg, ami lehetővé teszi számunkra, hogy saját 
     feldolgozást végezzünk az eseményre. Általában az ilyen típusú események esetén a cél az,
      hogy megakadályozzuk a böngésző alapértelmezett viselkedését, például hogy megakadályozzuk a 
    ájlok automatikus megnyitását, ha azokat a böngészőablakban húzzá*/

    const dragOver=function (e) {
        e.preventDefault();
    };
    /*Ez a kód egy olyan függvényt határoz meg dragOver,
     amely egy eseményobjektumot vesz paraméterként. A függvény meghívásakor megakadályozza az dragoveresemény alapértelmezett viselkedését, vagyis az eldobás letiltását. A függvény meghívásával preventDefault()lehetővé teszi az esést. Ezt a funkciót általában más fogd és vidd funkcióval együtt használják, hogy lehetővé tegyék egy húzható elemnek egy 
    érvényes ejtési célpontra való ejtését.*/
    const isAShipAlreadyPlaced=function (
        cells_With_Same_Y_Axis_As_DropTarget,
        shipData,
        xAxisOfDroppedShipFirstPosition,
    ) {
        const cellsWithShipPlaced = cells_With_Same_Y_Axis_As_DropTarget.filter(
            (cell) => cell.classList.contains("dropped"),
        );
        // eslint-disable-next-line radix
        const shipsPositionsInXAxis = cellsWithShipPlaced.map((cell) => parseInt(cell.dataset.index.split(",")[0]));
        const potentialShipPositionsForCurrentShip = [];
        const shipLength = shipData[1];
        for (let i = 0; i < shipLength; i+=1) {
            let droppedShipPosition = xAxisOfDroppedShipFirstPosition;
            droppedShipPosition += i;
            potentialShipPositionsForCurrentShip.push(droppedShipPosition);
        }
        const totalOverlappedShipPositions =
      potentialShipPositionsForCurrentShip.some((potentialShipPosition) => shipsPositionsInXAxis.includes(potentialShipPosition));
        if (totalOverlappedShipPositions) {
            return true;
        }
        return false;

    };
    /*Ez a kód egy függvényt definiál, amelynek a 
    neve isAShipAlreadyPlaced. A függvény bemenő paraméterei három darab tömb, az 
    első tartalmazza a lehetséges csempéket, amelyek azonos y koordinátával rendelkeznek, mint a 
    célhely, a második tartalmazza az adott hajó adatait, a harmadik pedig a célhely x koordinátáját.

A függvény célja az, hogy ellenőrizze, hogy az adott hajó által elfoglalt pozíciók átfedik-e 
azokat a pozíciókat, amelyeket már egy másik hajó elfoglalt a célhely közelében. Ehhez a függvény 
először meghatározza az összes olyan csempét, amelyet már egy másik hajó elfoglalt az adott y koordinátán. 
Ezután kiszámítja az adott hajó által elfoglalt pozíciókat az x tengely mentén, és ellenőrzi, hogy bármelyik 
pozíció átfedésben van-e a már elfoglalt pozíciókkal.

Ha az átfedés megtörtént, akkor a függvény true értékkel tér vissza, ellenkező esetben false értékkel.*/

    const isThereEnoughSpace=function (
        cells_With_Same_Y_Axis_As_DropTarget,
        shipData,
        xAxisOfDroppedShipFirstPosition,
    ) {
        const shiplength = Number(shipData[1]);
        const xAxisOfFirstCell =
      cells_With_Same_Y_Axis_As_DropTarget[0].dataset.index.split(",")[0];
        const xAxisOfLastCell =
      cells_With_Same_Y_Axis_As_DropTarget[
          cells_With_Same_Y_Axis_As_DropTarget.length - 1
      ].dataset.index.split(",")[0];
        if (
            xAxisOfFirstCell <= xAxisOfDroppedShipFirstPosition &&
      xAxisOfLastCell >= xAxisOfDroppedShipFirstPosition + (shiplength - 1)
        ) {
            // shilplength-1 because 95+5=100 but if you consider 95 and add 5 to it then it would be 99
            // you have to consider this nuance when working with gameboard cells
            return true; // means the ship can be placed
        }
        return false;

    };
    /*A függvény neve "isThereEnoughSpace", ami arra utal, hogy ellenőrzi, hogy elegendő hely áll-e 
    rendelkezésre a hajó elhelyezéséhez a játéktáblán.

A függvény három bemeneti paramétert vár:

    "cells_With_Same_Y_Axis_As_DropTarget" egy tömb, amely tartalmazza azokat a játéktáblacellákat, 
    amelyek azonos Y tengelyen vannak a csepphely céljával.
    "shipData" egy tömb, amely tartalmazza a hajó méretét és az irányát.
    "xAxisOfDroppedShipFirstPosition" az X tengelyen a hajó első pozíciója, amikor azt elhelyezik a 
    játéktáblán.

A függvény először kinyeri a hajó hosszát a "shipData" tömbből, majd az első és utolsó cella X tengelyét 
a "cells_With_Same_Y_Axis_As_DropTarget" tömbből. Ezután ellenőrzi, hogy az első cella X tengelye kisebb 
vagy egyenlő-e az elhelyezett hajó első pozíciója X tengelyével, és hogy az utolsó cella X tengelye nagyobb 
vagy egyenlő-e az elhelyezett hajó utolsó pozíciója X tengelyével. Ha igen, akkor a függvény igazzal tér 
vissza, ami azt jelenti, hogy elegendő hely áll rendelkezésre a hajó elhelyezéséhez a játéktáblán.
 Ellenkező esetben a függvény hamissal tér vissza.*/


    const checkIfDropValid=function (event, shipData) {
        const dropTargetCoordinates = event.target.dataset.index.split(",");
        const positionOfMouseOnTheShip = shipData[0];
        const xAxisOfDroppedShipFirstPosition =
      dropTargetCoordinates[0] - positionOfMouseOnTheShip;
        const humanGameboardCellsArray = [...humanGameboardCells];
        const cells_With_Same_Y_Axis_As_DropTarget = humanGameboardCellsArray.filter(
            (cell) => {
                const yAxisOfCell = cell.dataset.index.split(",")[1];
                const yAxisOfDropTarget = dropTargetCoordinates[1];
                return yAxisOfCell === yAxisOfDropTarget;
            },
        );

        if (
            isAShipAlreadyPlaced(
                cells_With_Same_Y_Axis_As_DropTarget,
                shipData,
                xAxisOfDroppedShipFirstPosition,
            )
        ) {
            return false; // means there is already a ship placed in the same axis
        } else if (
            isThereEnoughSpace(
                cells_With_Same_Y_Axis_As_DropTarget,
                shipData,
                xAxisOfDroppedShipFirstPosition,
            )
        ) {
            return true; // means the ship can be placed
        }
        return false;

    };
    /*A függvény neve "checkIfDropValid", ami azt jelenti, hogy ellenőrzi, hogy érvényes-e a hajó 
    elhelyezése a játéktáblán.

A függvény két bemeneti paramétert vár:

    "event", amely a hajó elhelyezésekor keletkező eseményt jelenti.
    "shipData", amely tartalmazza a hajó méretét és az irányát.

A függvény először kinyeri a csepphely X és Y koordinátáit az eseményből, majd kiszámítja az elhelyezett 
hajó első pozíciója X tengelyén a "positionOfMouseOnTheShip" változó felhasználásával. Ezután másolatot 
készít az "humanGameboardCells" tömbből, és kiválasztja azokat a cellákat, amelyek azonos Y tengelyen 
vannak a csepphellyel.

A függvény további két függvényt hív meg:

    "isAShipAlreadyPlaced" függvényt, amely ellenőrzi, hogy van-e már hajó azonos Y tengelyen az elhelyezett 
    hajóval.
    "isThereEnoughSpace" függvényt, amely ellenőrzi, hogy elegendő hely áll-e rendelkezésre az elhelyezendő
     hajó számára azonos Y tengelyen.

Ha van már hajó azonos Y tengelyen, akkor a függvény hamissal tér vissza, mert az elhelyezés érvénytelen. 
Ha nincs más hajó azonos Y tengelyen, akkor meghívja az "isThereEnoughSpace" függvényt. Ha van elegendő 
hely az elhelyezéshez, akkor a függvény igazzal tér vissza, különben hamissal tér vissza.*/

    const totalShips = 5;
    let dropCount = 0;
    /*A totalShips nevű változó egy konstans értéket jelöl, amely azt mondja meg, hogy hány hajó 
    van a játékban összesen.

A dropCount változó egy változó, amely azon számlálja a hajókat, amelyeket a felhasználó 
már elhelyezett a játéktáblán. Kezdetben 0 értéket kap, és minden egyes hajó elhelyezésekor 
növekszik eggyel. A dropCount változó arra használható, hogy meghatározzuk, hogy az összes hajó 
már elhelyezésre került-e a játékban, vagy van-e még hátra.
 Ez az információ lehetővé teszi a játék állapotának nyomon követését és ellenőrzését.*/

    const drop=function (e) {
        e.stopPropagation(); // stops the browser from redirecting.

        const xAxisOfDropTarget = Number(e.target.dataset.index.split(",")[0]);
        const shipDataJson = e.dataTransfer.getData("ship-data");
        const shipData = JSON.parse(shipDataJson);

        if (!checkIfDropValid(e, shipData)) {
            return false; // this will stop the function and thus the drop will not be handled
        }

        const shiplength = shipData[1];
        const positionOfMouseOnTheShip = shipData[0];
        const xAxisOfShipStartPosition = xAxisOfDropTarget - positionOfMouseOnTheShip;
        const shipName = shipData[2];
        human.gameboard.placeShip(`${ shipName }`, xAxisOfShipStartPosition);
        for (let i = 0; i < shiplength; i+=1) {
            humanGameboardCells[xAxisOfShipStartPosition + i].style.background =
        "#444444";
            humanGameboardCells[xAxisOfShipStartPosition + i].classList.add(
                "dropped",
            );
        }

        const draggable = document.querySelector(`#${ shipName }`);
        draggable.style.display = "none";
        dropCount += 1;
        if (dropCount === totalShips) {
            const startGameButton = document.querySelector("#start");
            startGameButton.style.display = "block";
            
        }
    };
    /*Ez a függvény kezeli az eseményt, amikor a felhasználó egy hajót elhelyez a játéktáblán.
     Az első dolga, hogy ellenőrizze, hogy a hajó elhelyezése érvényes-e a checkIfDropValid függvénnyel. 
    Ha az elhelyezés érvénytelen, a függvény visszatér és nem folytatódik a kód futtatása.

Ha az elhelyezés érvényes, akkor a függvény meghatározza a hajó kezdőpozícióját, amelyet a
felhasználó az egérrel választott ki, majd elhelyezi a hajót a humanGameboardCells tömb megfelelő 
celláiba a placeShip függvénnyel. Ezt követően a függvény beállítja a hajó celláinak hátterét a "#444444" 
színre, és hozzáadja azokhoz a dropped osztályt, hogy jelezze, hogy a hajó már elhelyezésre került.

A függvény befejezése előtt eltávolítja a hajót a képernyőről, növeli a dropCount változót, és ellenőrzi, 
hogy az összes hajó már elhelyezésre került-e. Ha igen, akkor megjeleníti a "startGameButton" gombot a
 felhasználó számára.*/
    

    const humanGameboardCells = document.querySelectorAll(
        "#friendly-area-gameboard .square_div",
    );
    /* Ez a kódrészlet egy NodeList-et ad vissza, amely az összes olyan HTML elemet tartalmazza, amelynek az osztálya "square_div" és amelyek a "#friendly-area-gameboard" HTML elemen belül találhatók.

Ez a kódrészlet valószínűleg egy játéktáblát kezelő JavaScript kód része, ahol a "humanGameboardCells" 
változóval hivatkoznak ezekre az elemekre, és használják őket a játékmenet során. Az elemeket a 
querySelectorAll() metódus segítségével választják ki, amely a CSS szelektorokat használja az elemek
 kiválasztására. Az első paraméter a CSS szelektor, amely alapján kiválasztják 
az elemeket, a második paraméter pedig az a HTML elem, amelyen belül az elemeket keresik*/
    humanGameboardCells.forEach((cell) => {
        cell.addEventListener("dragenter", dragEnter);
        cell.addEventListener("dragover", dragOver);
        cell.addEventListener("drop", drop);
    });
    /*Ez a kód egy összefüggő blokkot alkot, amely a fenti kódrészletre épül. A kódban az 
    "humanGameboardCells" NodeList-en végrehajtanak egy forEach() metódust, amely bejárja az 
    összes elemet, majd az összes elemhez hozzáadnak három eseményfigyelőt: "dragenter", "dragover" 
    és "drop".

Ezek az eseményfigyelők a HTML5 Drag and Drop API-hoz kapcsolódnak, amely lehetővé teszi 
az elemek áthelyezését egyik helyről a másikra a weboldalon belül. A "dragenter" esemény akkor történik, 
amikor egy elem belép egy másik elem területére, a "dragover" esemény akkor történik, amikor az elem mozgás
 közben 
van, a "drop" esemény pedig akkor történik, amikor az elem elengedésre kerül.

A kód célja, hogy az összes "humanGameboardCells" elemhez hozzáadja ezeket az eseményfigyelőket, hogy a felhasználók áthelyezhessék a játékmezőkön lévő hajókat és célzókijelölőket. Az eseményfigyelők végrehajtják a megfelelő függvényeket ("dragEnter", "dragOver", "drop"), amelyek meghatározzák, hogyan viselkedjenek az elemek az adott események során.*/

    const draggableShips = document.querySelectorAll(".draggable");
    draggableShips.forEach((ship) => {
        ship.addEventListener("dragstart", dragstart);
    });
};

/*Ez a kód részlet arra szolgál, hogy a weboldalon lévő összes HTML elemhez, amelyeknek a "draggable"
 osztálya van, hozzáadjon egy "dragstart" eseményfigyelőt. Az "addDragDropFeature" függvény, amelynek 
 része ez a kód, általában a weboldal játékterének JavaScript kódjába van beillesztve, és a hajók és célzók
  könnyű mozgatását teszi lehetővé a játékmezőn.

Az "addDragDropFeature" függvény hozzáadja a Drag and Drop API-hoz kapcsolódó funkciókat a játékmezőkön 
lévő hajókhoz és célzókijelölőkhöz. Az "addDragDropFeature" függvény ezen a kódrészletén keresztül a
 weboldal minden "draggable" eleméhez hozzáadja az eseményfigyelőt, amely a felhasználók által húzott 
 hajók és célzókijelölők mozgatását kezeli.

A "dragstart" esemény akkor történik, amikor az elemet elkezdik húzni, és az eseményfigyelőnek 
megfelelően reagálnia kell arra, hogy mely elemek mozoghatnak és hova tehetők a játékmezőn belül. 
Az eseményfigyelő végrehajtja a "dragstart" függvényt, amely meghatározza az elem mozgatásának 
kezdőállapotát. Az "addDragDropFeature" függvény hozzájárul a 
játékélmény javításához és a játékosoknak lehetővé teszi a hajók és célzók könnyű mozgatását a 
játékmezőn.*/
export { addDragDropFeature };
/*Ez a kódrészlet egy export utasítás, amely exportálja az 
"addDragDropFeature" függvényt, hogy más fájlok is használhassák ezt a függvényt.

Az export utasítás lehetővé teszi, hogy a "addDragDropFeature" 
függvényt más fájlokban használják, ha hozzáférnek ehhez a fájlhoz. Például, 
ha egy másik fájl használni akarja ezt a függvényt, akkor importálni kell a fájlt,
 amelyben az exportálták ezt a függvényt. Az exportált függvények és változók használata 
lehetővé teszi a kód modularizálását, újrafelhasználhatóságát és az
 egyszerűbb karbantarthatóságot.*/