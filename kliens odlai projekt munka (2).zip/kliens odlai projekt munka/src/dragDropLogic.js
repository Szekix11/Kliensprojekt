/* eslint-disable max-len */
const addDragDropFeature=function (human) {
    const allDraggableDivs = document.querySelectorAll(".draggable");
    allDraggableDivs.forEach((div) => {
        for (let i = 0; i < div.children.length; i+=1) {
            div.children[i].addEventListener("mousedown", (e) => {
               
                div.dataset.index = e.target.dataset.index; 
            });
        }
    });  
    /*Ez a függvény az egérdrag esemény (dragstart) kezelője, amely akkor fut le, amikor a felhasználó 
    elkezdi húzni az egérrel az adott hajót (shipBeingDragged). A függvény által végzett tevékenységek a következők:

    Először eltárolja a hajót, amelyet elhúztak, a shipBeingDragged változóban.
    Meghatározza a hajó pozícióját az egérrel való érintkezésnél (positionOfMouseOnTheShip), amelyet az 
    adott hajó data-index attribútuma határoz meg.
    Meghatározza a hajó hosszát (lengthOfTheShip), amelyet szintén a hajó data-shiplength attribútuma 
    határoz meg.
    Elmenti a hajó azonosítóját (shipName) az id attribútumból.
    Végül az összes fenti adatot egy tömbbe helyezi (transferData), majd ezt a tömböt JSON formátumban 
    eltárolja a ship-data adatként (setData) az esemény (e.dataTransfer) adataiban.
    Ez a függvény tehát az egérdrag esemény kezelőjeként az adott hajó pozícióját, hosszát és azonosítóját 
    tárolja, majd ezeket adatként továbbítja a drop eseményhez kapcsolódó kezelőnek. */

    const dragstart=function (e) {
        const shipBeingDragged = e.target;
        const positionOfMouseOnTheShip = shipBeingDragged.dataset.index;
        const lengthOfTheShip = shipBeingDragged.dataset.shiplength;
        const shipName = shipBeingDragged.id;
        const transferData = [positionOfMouseOnTheShip, lengthOfTheShip, shipName];
        e.dataTransfer.setData("ship-data", JSON.stringify(transferData));
    };
     /* Ez a kód egy olyan függvényt határoz meg dragstart, amely egy paramétert vesz fel e. 
     Ezt a funkciót általában az esemény eseményfigyelőjeként használják dragstart. 
     Amikor a felhasználó elkezdi húzni egy elemet, ez a funkció kivon néhány adatot a húzott 
     elemről, például a pozícióját, hosszát és azonosítóját, és ezeket az adatokat egy tömbben tárolja.
     transferData. Ezeket az adatokat ezután 
     JSON-karakterláncként szerializálják, ésdataTransfer.setData()módszer.*/
    const dragEnter=function (e) {
        e.preventDefault();
    };
    /*Az dragEnter függvény meghívódik, amikor egy húzható elem bejut egy 
    célélem területére. Az első dolog, amit a függvény tesz, az az esemény alapértelmezett
     működésének megakadályozása (preventDefault). Ez azt jelenti, hogy az esemény további 
     alapértelmezett feldolgozása nem történik meg, ami lehetővé teszi számunkra, hogy saját 
     feldolgozást végezzünk az eseményre. Általában az ilyen típusú események esetén a cél az,
      hogy megakadályozzuk a böngésző alapértelmezett viselkedését, például hogy megakadályozzuk a 
    ájlok automatikus megnyitását, ha azokat a böngészőablakban húzzá*/

    const dragOver=function (e) {
        e.preventDefault();
    };
    /*Ez a kód egy olyan függvényt határoz meg dragOver,
     amely egy eseményobjektumot vesz paraméterként. A függvény meghívásakor megakadályozza az dragoveresemény alapértelmezett viselkedését, vagyis az eldobás letiltását. A függvény meghívásával preventDefault()lehetővé teszi az esést. Ezt a funkciót általában más fogd és vidd funkcióval együtt használják, hogy lehetővé tegyék egy húzható elemnek egy 
    érvényes ejtési célpontra való ejtését.*/
    const isAShipAlreadyPlaced=function (
        cells_With_Same_Y_Axis_As_DropTarget,
        shipData,
        xAxisOfDroppedShipFirstPosition,
    ) {
        const cellsWithShipPlaced = cells_With_Same_Y_Axis_As_DropTarget.filter(
            (cell) => cell.classList.contains("dropped"),
        );
        // eslint-disable-next-line radix
        const shipsPositionsInXAxis = cellsWithShipPlaced.map((cell) => parseInt(cell.dataset.index.split(",")[0]));
        const potentialShipPositionsForCurrentShip = [];
        const shipLength = shipData[1];
        for (let i = 0; i < shipLength; i+=1) {
            let droppedShipPosition = xAxisOfDroppedShipFirstPosition;
            droppedShipPosition += i;
            potentialShipPositionsForCurrentShip.push(droppedShipPosition);
        }
        const totalOverlappedShipPositions =
      potentialShipPositionsForCurrentShip.some((potentialShipPosition) => shipsPositionsInXAxis.includes(potentialShipPosition));
        if (totalOverlappedShipPositions) {
            return true;
        }
        return false;

    };
    /*Ez a kód egy függvényt definiál, amelynek a 
    neve isAShipAlreadyPlaced. A függvény bemenő paraméterei három darab tömb, az 
    első tartalmazza a lehetséges csempéket, amelyek azonos y koordinátával rendelkeznek, mint a 
    célhely, a második tartalmazza az adott hajó adatait, a harmadik pedig a célhely x koordinátáját.

A függvény célja az, hogy ellenőrizze, hogy az adott hajó által elfoglalt pozíciók átfedik-e 
azokat a pozíciókat, amelyeket már egy másik hajó elfoglalt a célhely közelében. Ehhez a függvény 
először meghatározza az összes olyan csempét, amelyet már egy másik hajó elfoglalt az adott y koordinátán. 
Ezután kiszámítja az adott hajó által elfoglalt pozíciókat az x tengely mentén, és ellenőrzi, hogy bármelyik 
pozíció átfedésben van-e a már elfoglalt pozíciókkal.

Ha az átfedés megtörtént, akkor a függvény true értékkel tér vissza, ellenkező esetben false értékkel.*/

    const isThereEnoughSpace=function (
        cells_With_Same_Y_Axis_As_DropTarget,
        shipData,
        xAxisOfDroppedShipFirstPosition,
    ) {
        const shiplength = Number(shipData[1]);
        const xAxisOfFirstCell =
      cells_With_Same_Y_Axis_As_DropTarget[0].dataset.index.split(",")[0];
        const xAxisOfLastCell =
      cells_With_Same_Y_Axis_As_DropTarget[
          cells_With_Same_Y_Axis_As_DropTarget.length - 1
      ].dataset.index.split(",")[0];
        if (
            xAxisOfFirstCell <= xAxisOfDroppedShipFirstPosition &&
      xAxisOfLastCell >= xAxisOfDroppedShipFirstPosition + (shiplength - 1)
        ) {
            // shilplength-1 because 95+5=100 but if you consider 95 and add 5 to it then it would be 99
            // you have to consider this nuance when working with gameboard cells
            return true; // means the ship can be placed
        }
        return false;

    };
    /*A függvény neve "isThereEnoughSpace", ami arra utal, hogy ellenőrzi, hogy elegendő hely áll-e 
    rendelkezésre a hajó elhelyezéséhez a játéktáblán.

A függvény három bemeneti paramétert vár:

    "cells_With_Same_Y_Axis_As_DropTarget" egy tömb, amely tartalmazza azokat a játéktáblacellákat, 
    amelyek azonos Y tengelyen vannak a csepphely céljával.
    "shipData" egy tömb, amely tartalmazza a hajó méretét és az irányát.
    "xAxisOfDroppedShipFirstPosition" az X tengelyen a hajó első pozíciója, amikor azt elhelyezik a 
    játéktáblán.

A függvény először kinyeri a hajó hosszát a "shipData" tömbből, majd az első és utolsó cella X tengelyét 
a "cells_With_Same_Y_Axis_As_DropTarget" tömbből. Ezután ellenőrzi, hogy az első cella X tengelye kisebb 
vagy egyenlő-e az elhelyezett hajó első pozíciója X tengelyével, és hogy az utolsó cella X tengelye nagyobb 
vagy egyenlő-e az elhelyezett hajó utolsó pozíciója X tengelyével. Ha igen, akkor a függvény igazzal tér 
vissza, ami azt jelenti, hogy elegendő hely áll rendelkezésre a hajó elhelyezéséhez a játéktáblán.
 Ellenkező esetben a függvény hamissal tér vissza.*/


    const checkIfDropValid=function (event, shipData) {
        const dropTargetCoordinates = event.target.dataset.index.split(",");
        const positionOfMouseOnTheShip = shipData[0];
        const xAxisOfDroppedShipFirstPosition =
      dropTargetCoordinates[0] - positionOfMouseOnTheShip;
        const humanGameboardCellsArray = [...humanGameboardCells];
        const cells_With_Same_Y_Axis_As_DropTarget = humanGameboardCellsArray.filter(
            (cell) => {
                const yAxisOfCell = cell.dataset.index.split(",")[1];
                const yAxisOfDropTarget = dropTargetCoordinates[1];
                return yAxisOfCell === yAxisOfDropTarget;
            },
        );

        if (
            isAShipAlreadyPlaced(
                cells_With_Same_Y_Axis_As_DropTarget,
                shipData,
                xAxisOfDroppedShipFirstPosition,
            )
        ) {
            return false; // means there is already a ship placed in the same axis
        } else if (
            isThereEnoughSpace(
                cells_With_Same_Y_Axis_As_DropTarget,
                shipData,
                xAxisOfDroppedShipFirstPosition,
            )
        ) {
            return true; // means the ship can be placed
        }
        return false;

    };
    /*A függvény neve "checkIfDropValid", ami azt jelenti, hogy ellenőrzi, hogy érvényes-e a hajó 
    elhelyezése a játéktáblán.

A függvény két bemeneti paramétert vár:

    "event", amely a hajó elhelyezésekor keletkező eseményt jelenti.
    "shipData", amely tartalmazza a hajó méretét és az irányát.

A függvény először kinyeri a csepphely X és Y koordinátáit az eseményből, majd kiszámítja az elhelyezett 
hajó első pozíciója X tengelyén a "positionOfMouseOnTheShip" változó felhasználásával. Ezután másolatot 
készít az "humanGameboardCells" tömbből, és kiválasztja azokat a cellákat, amelyek azonos Y tengelyen 
vannak a csepphellyel.

A függvény további két függvényt hív meg:

    "isAShipAlreadyPlaced" függvényt, amely ellenőrzi, hogy van-e már hajó azonos Y tengelyen az elhelyezett 
    hajóval.
    "isThereEnoughSpace" függvényt, amely ellenőrzi, hogy elegendő hely áll-e rendelkezésre az elhelyezendő
     hajó számára azonos Y tengelyen.

Ha van már hajó azonos Y tengelyen, akkor a függvény hamissal tér vissza, mert az elhelyezés érvénytelen. 
Ha nincs más hajó azonos Y tengelyen, akkor meghívja az "isThereEnoughSpace" függvényt. Ha van elegendő 
hely az elhelyezéshez, akkor a függvény igazzal tér vissza, különben hamissal tér vissza.*/

    const totalShips = 5;
    let dropCount = 0;

    const drop=function (e) {
        e.stopPropagation(); // stops the browser from redirecting.

        const xAxisOfDropTarget = Number(e.target.dataset.index.split(",")[0]);
        const shipDataJson = e.dataTransfer.getData("ship-data");
        const shipData = JSON.parse(shipDataJson);

        if (!checkIfDropValid(e, shipData)) {
            return false; // this will stop the function and thus the drop will not be handled
        }

        const shiplength = shipData[1];
        const positionOfMouseOnTheShip = shipData[0];
        const xAxisOfShipStartPosition = xAxisOfDropTarget - positionOfMouseOnTheShip;
        const shipName = shipData[2];
        human.gameboard.placeShip(`${ shipName }`, xAxisOfShipStartPosition);
        for (let i = 0; i < shiplength; i+=1) {
            humanGameboardCells[xAxisOfShipStartPosition + i].style.background =
        "#444444";
            humanGameboardCells[xAxisOfShipStartPosition + i].classList.add(
                "dropped",
            );
        }

        const draggable = document.querySelector(`#${ shipName }`);
        draggable.style.display = "none";
        dropCount += 1;
        if (dropCount === totalShips) {
            const startGameButton = document.querySelector("#start");
            startGameButton.style.display = "block";
            
        }
    };

    

    const humanGameboardCells = document.querySelectorAll(
        "#friendly-area-gameboard .square_div",
    );
    humanGameboardCells.forEach((cell) => {
        cell.addEventListener("dragenter", dragEnter);
        cell.addEventListener("dragover", dragOver);
        cell.addEventListener("drop", drop);
    });

    const draggableShips = document.querySelectorAll(".draggable");
    draggableShips.forEach((ship) => {
        ship.addEventListener("dragstart", dragstart);
    });
};

export { addDragDropFeature };
