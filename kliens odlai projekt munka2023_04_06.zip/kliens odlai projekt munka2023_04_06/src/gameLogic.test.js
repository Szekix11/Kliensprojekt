import {ship,gameBoard,humanPlayer,ai} from './gameLogic'; /*Ez a kód 
egy modulból importálja a ship, gameBoard, humanPlayer és ai objektumokat, amelyek a 
hajók, játéktábla, emberi játékos és mesterséges intelligencia logikáját
 definiálják. Ezután ezeket az objektumokat használhatjuk egy másik fájlban*/

test('hit function marks hit positions',()=>{
    const shipObj=ship('carrier',2);
    shipObj.hit(1);
    expect(shipObj.hitPositions).toContain(1)
}) /*Ez egy unit teszt, amely azt ellenőrzi, hogy a ship objektum hit metódusa helyesen jelöli-e meg a 
találati pozíciókat a hajón belül.

Létrehoz egy új ship objektumot, amelynek hossza 2, és a típusa "carrier".
Meghívja a hit metódust az objektumon a 1-es index paraméterrel.
Végül az expect függvénnyel ellenőrzi, hogy az objektum hitPositions tömbje tartalmazza-e 
a 1-es indexet. Ha igen, a teszt sikeresen lefutott, ha nem, akkor hibát dob.*/

test('placeShip function add ships to the shipList array',()=>{
    const gameboard=gameBoard();
    gameboard.placeShip('carrier',2);
    expect(gameboard.shipList.length).toBe(1);
}) /*Ez a kód teszteli, hogy a placeShip függvény helyesen hozzáadja-e az új hajót a 
shipList tömbhöz a gameBoard objektumban. Létrehoz egy gameBoard objektumot, majd 
meghívja a placeShip függvényt az "carrier" típusú hajóval és a 2. pozícióval. Ezután ellenőrzi,
 hogy az új hajó hozzá lett-e adva a shipList
 tömbhöz az expect függvénnyel. Ha a shipList tömb hossza 1, akkor a teszt sikeres.*/

test('receiveAttack function sends the hit function to the correct ship',()=>{
    const gameboard=gameBoard();
    gameboard.placeShip('carrier',2)
    gameboard.receiveAttack(2);
    expect(gameboard.shipList[0].hitPositions).toContain(2);
    gameboard.receiveAttack(3);
    expect(gameboard.shipList[0].hitPositions).toContain(3);
})
/*Ez a kód teszteli, hogy a receiveAttack() függvény megfelelően működik-e 
a gameBoard objektumon. Az első részben helyezünk el egy hajót, majd megadunk neki 
két találatot a receiveAttack() függvény segítségével. Az utolsó 
két sor azt ellenőrzi, hogy a hitPositions tömb a találatok helyes tárolását jelzi-e*/
//
test('gameBoard keep record of the missed attacks',()=>{
    const gameboard=gameBoard();
    gameboard.placeShip('carrier',2)
    gameboard.receiveAttack(1);
    gameboard.receiveAttack(2);
    expect(gameboard.missedHits).toContain(1)
})/*Ez a kód egy teszteset, ami ellenőrzi, hogy a gameBoard objektum
 helyesen rögzíti az elhibázott lövéseket. A tesztesetben először a gameboard
  objektum létrehozása után egy hajót helyeznek el rajta. Ezután az első két lövést
   elvégzik az objektumon keresztül, és az elvárt eredmény az, hogy az első lövés 
nem találta el a hajót, és ezt rögzítették az objektum missedHits tömbjében.*/

test('if a hit is found,for loop inside receiveAttack function breaks',()=>{
    const gameboard=gameBoard();
    gameboard.placeShip('carrier',2)
    gameboard.receiveAttack(2);
    expect(gameboard.shipList[0].hitPositions).toContain(2);
    expect(gameboard.missedHits.length).toBe(0); 
}) /*Ez a kód teszteli, hogy ha az receiveAttack függvényen belül talál egy 
találatot, akkor a ciklus megszakad, és nem hajtja végre az összes további csekkolást. 
A teszt két elvárást ellenőriz: hogy a találat a megfelelő hajónál legyen megjelölve, és 
hogy a nem talált támadások listája üres legyen.*/

test('ai can make random attack',()=>{
    const human=humanPlayer();
    human.gameboard.placeShip('carrier',5);
    const gameBoardSize=100;
    const aiPlayer=ai(gameBoardSize);
    aiPlayer.attack(human.gameboard);
    try{
        expect(human.gameboard.shipList[0].hitPositions.length).toBe(1);
    }catch{
        expect(human.gameboard.missedHits.length).toBe(1)
    }
}) /*Ez a kód teszteli, hogy az AI játékos véletlenszerűen tud-e támadni a
 Human játékos játékterén, és talál-e el egy hajót. A teszt azt várja el, hogy a
  Human játékos játékterén található első hajóra vonatkozó találati pozíciók száma 
  legyen 1, ha az AI talált, vagy hogy az első körben az AI találta el a hajót, 
és az első találati pozíció nem létezik, ha az AI nem talált el.*/

test('ai can attack adjacent cells when there is a successful attack',()=>{
    const human=humanPlayer();
    human.gameboard.placeShip('carrier',5);
    human.gameboard.placeShip('carrier',10);
    const gameBoardSize=100;
    const aiPlayer=ai(gameBoardSize);
   
    human.gameboard.shipList[1].hitPositions.push(10);//attacks first position of second ship
    aiPlayer.attack(human.gameboard);
    aiPlayer.attack(human.gameboard);
    aiPlayer.attack(human.gameboard);
    aiPlayer.attack(human.gameboard);
    expect(human.gameboard.shipList[1].hitPositions).toEqual([10,11,12,13,14])
   
    human.gameboard.shipList[0].hitPositions.push(5);//attacks first position of first ship
    aiPlayer.attack(human.gameboard);
    aiPlayer.attack(human.gameboard);
    aiPlayer.attack(human.gameboard);
    aiPlayer.attack(human.gameboard);
    expect(human.gameboard.shipList[0].hitPositions).toEqual([5,6,7,8,9])
}) /*Ez a kód teszteli, hogy az AI játékos a megfelelő stratégiát használja-e a támadások során. 
A tesztben először két hajót helyeznek el az emberi játékos játéktábláján, majd az AI támadni kezd. 
Az AI első támadása a második hajó első pozíciója, majd az AI további támadásokat hajt végre a körülötte 
lévő mezőkre, míg az összes mezőt el nem találja a hajó körül. Az utolsó két ellenőrzés megnézi, hogy a 
hajók megfelelő pozícióit találta-e el az AI, és hogy a hajók az elvárt sorrendben állnak-e.*/

test('ai stops attacking adjacent cells if there is unsuccessful attack',()=>{
    const human=humanPlayer();
    const gameBoardSize=100;
    const aiPlayer=ai(gameBoardSize);
    human.gameboard.placeShip('submarine',5);
    
    human.gameboard.shipList[0].hitPositions.push(5);
    aiPlayer.attack(human.gameboard);
    expect(human.gameboard.shipList[0].hitPositions).toEqual([5,6])
    
    aiPlayer.attack(human.gameboard);//missed hit because ship length for submarine is 2
    aiPlayer.attack(human.gameboard);//missed hit for same reason
    expect(human.gameboard.missedHits).not.toEqual([7,8]); 
})
/*Ez a kód az AI játékos viselkedését teszteli a következő szituációban:

    A emberi játékos (humanPlayer) elhelyezi a "submarine" típusú hajóját az 5. cellától kezdődően 
    a gameboard-on (gameBoard).
    Az AI játékos (ai) a második cellát találta el a "submarine" hajón, és ezt az információt 
    elmenti.
    Az AI játékos ezt követően két további cellára támad, de mivel a "submarine" hajó 
    hossza csak 2, mindkét támadás sikertelen lesz (vagyis nem találta el a hajót).
    A teszt ellenőrzi, hogy az AI játékos helyesen viselkedik-e a sikertelen támadások után, vagyis abbahagyja-e az olyan szomszédos cellák támadását, amelyek az előző sikeres 
    támadás alapján következnének, de azokon a hajó már nem található.*/
describe('gameboard can report whether or not all ship is sunk',()=>{
    const gameboard=gameBoard();
    gameboard.placeShip('submarine',5); //ship is in 5 and 6 number cell
    gameboard.placeShip('submarine',7); //ship is in 7 and 8 number cell
    
    test('gameboard can report whether all ship is sunk',()=>{
        for(let i=5;i<=8;i++){
            gameboard.receiveAttack(i); //attacks 5,6,7,8 number cells
        }
        expect(gameboard.areAllShipSunk()).toBe(true)
    })

    test('gameboard can report all ship is not sunk',()=>{
        for(let i=5;i<=6;i++){
            gameboard.receiveAttack(i); //only attacks cell number 5,6
        }
        expect(gameboard.areAllShipSunk()).toBe(false);
    })
})  /*Ez a kód egy tesztesetet ír le a gameBoard objektum areAllShipSunk függvényének 
vizsgálatára, amely visszatér azzal, hogy minden hajó elsüllyedt-e vagy sem. 
Először a teszteset ellenőrzi, hogy az összes hajó elsüllyedt-e, miután minden 
hajót megtámadott. A második teszteset 
arra utal, hogy nem minden hajó elsüllyedt, miután csak egy hajót támadtak me*/